[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$TargetRepo
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$overlay = Join-Path $PSScriptRoot "overlay"
$target = (Resolve-Path -LiteralPath $TargetRepo).Path
if (-not (Test-Path -LiteralPath (Join-Path $target ".git"))) {
    throw "TargetRepo is not a Git checkout: $target"
}

$files = Get-ChildItem -File -Recurse -LiteralPath $overlay
foreach ($file in $files) {
    $relative = [IO.Path]::GetRelativePath($overlay, $file.FullName)
    $destination = Join-Path $target $relative
    $parent = Split-Path -Parent $destination
    New-Item -ItemType Directory -Force -Path $parent | Out-Null
    Copy-Item -LiteralPath $file.FullName -Destination $destination -Force
}

Write-Host "Applied $($files.Count) files to $target" -ForegroundColor Green
