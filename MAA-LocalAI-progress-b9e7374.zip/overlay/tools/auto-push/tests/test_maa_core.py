from pathlib import Path

import pytest

from autopush.maa_core import (
    MaaCoreLibrary,
    MaaEvent,
    extract_oper_box_details,
    summarize_events,
)


MAA_CORE = Path(r"D:\work\CodexOutputs\MAA-LocalAI\MaaCore.dll")


@pytest.mark.skipif(not MAA_CORE.is_file(), reason="local MAA Core package not found")
def test_maa_core_loads_and_reports_version():
    library = MaaCoreLibrary(MAA_CORE)
    assert library.version()


def test_task_completion_still_requires_result_verification():
    summary = summarize_events(
        [
            MaaEvent(1, {"what": "CopilotAction", "details": {"name": "Deploy"}}),
            MaaEvent(2, {"what": "TaskChainCompleted"}),
        ]
    )
    assert summary["task_completed"]
    assert summary["copilot_action_count"] == 1
    assert summary["verification_required"]
    assert not summary["verified"]


def test_extract_oper_box_details_uses_last_complete_payload():
    events = [
        MaaEvent(
            3,
            {
                "what": "OperBoxInfo",
                "details": {"done": False, "own_opers": []},
            },
        ),
        MaaEvent(
            3,
            {
                "what": "OperBoxInfo",
                "details": {
                    "done": True,
                    "own_opers": [{"name": "圣聆初雪", "elite": 2}],
                },
            },
        ),
    ]

    details = extract_oper_box_details(events)

    assert details is not None
    assert details["own_opers"][0]["name"] == "圣聆初雪"
