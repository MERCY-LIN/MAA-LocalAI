"""Small ADB controller for repeatable emulator operations."""

from __future__ import annotations

import subprocess
import threading
import time
from dataclasses import dataclass, field as dataclass_field
from pathlib import Path

from .metrics import RoundMetrics
from .recognizer import decode_png


class AdbError(RuntimeError):
    """Raised when an ADB command fails."""


@dataclass
class AdbClient:
    """Thin wrapper that records every repeated device operation."""

    adb_path: str | Path
    serial: str = "emulator-5554"
    metrics: RoundMetrics | None = None
    timeout_seconds: int = 30
    minimum_capture_interval_seconds: float = 1.5
    _capture_lock: threading.Lock = dataclass_field(
        default_factory=threading.Lock,
        init=False,
        repr=False,
    )
    _last_capture_at: float = dataclass_field(default=0.0, init=False)
    _last_capture: bytes | None = dataclass_field(default=None, init=False)

    def _command(self, *arguments: str) -> list[str]:
        return [
            str(self.adb_path),
            "-s",
            self.serial,
            *arguments,
        ]

    def _run(self, *arguments: str) -> bytes:
        if self.metrics is not None:
            self.metrics.record_tool_call()
        completed = subprocess.run(
            self._command(*arguments),
            check=False,
            capture_output=True,
            timeout=self.timeout_seconds,
        )
        if completed.returncode != 0:
            stderr = completed.stderr.decode("utf-8", errors="replace").strip()
            raise AdbError(stderr or f"ADB exited with {completed.returncode}")
        return completed.stdout

    def devices(self) -> list[str]:
        output = self._run("devices").decode("utf-8", errors="replace")
        serials: list[str] = []
        for line in output.splitlines()[1:]:
            fields = line.split()
            if len(fields) >= 2 and fields[1] == "device":
                serials.append(fields[0])
        return serials

    def capture_png(self, *, force: bool = False) -> bytes:
        with self._capture_lock:
            now = time.monotonic()
            if (
                not force
                and self._last_capture is not None
                and now - self._last_capture_at
                < self.minimum_capture_interval_seconds
            ):
                return self._last_capture
            if self.metrics is not None:
                self.metrics.record_screenshot()
            payload = self._run("exec-out", "screencap", "-p")
            self._last_capture = payload
            self._last_capture_at = now
            return payload

    def capture_bgr(self):
        return decode_png(self.capture_png())

    def click(self, x: int, y: int) -> None:
        self._run("shell", "input", "tap", str(x), str(y))

    def swipe(
        self,
        start_x: int,
        start_y: int,
        end_x: int,
        end_y: int,
        duration_ms: int = 300,
    ) -> None:
        self._run(
            "shell",
            "input",
            "swipe",
            str(start_x),
            str(start_y),
            str(end_x),
            str(end_y),
            str(duration_ms),
        )

    def back(self) -> None:
        self._run("shell", "input", "keyevent", "4")
