"""Minimal ctypes adapter for MAA Core Copilot execution."""

from __future__ import annotations

import ctypes
import json
import os
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from .metrics import RoundMetrics
from .resource_limits import (
    lower_current_process_priority,
    restore_current_process_priority,
)

AsstBool = ctypes.c_uint8
AsstTaskId = ctypes.c_int32
AsstHandle = ctypes.c_void_p
AsstApiCallback = ctypes.CFUNCTYPE(
    None,
    ctypes.c_int32,
    ctypes.c_char_p,
    ctypes.c_void_p,
)


class MaaCoreError(RuntimeError):
    """Raised when MAA Core rejects a call or task."""


@dataclass(frozen=True)
class MaaEvent:
    message_id: int
    details: dict[str, Any]


def summarize_events(events: list[MaaEvent]) -> dict[str, Any]:
    """Summarize callbacks without treating task completion as a clear result."""

    task_errors = [
        event.details
        for event in events
        if event.details.get("what") == "TaskChainError"
    ]
    completed = any(
        event.details.get("what") == "TaskChainCompleted"
        for event in events
    )
    actions = [
        event.details
        for event in events
        if event.details.get("what") == "CopilotAction"
    ]
    return {
        "task_completed": completed,
        "task_errors": task_errors,
        "copilot_action_count": len(actions),
        "verification_required": True,
        "verified": False,
    }


def extract_oper_box_details(events: list[MaaEvent]) -> dict[str, Any] | None:
    """Return the final OperBox payload from nested MAA callbacks."""

    def find(value: Any) -> dict[str, Any] | None:
        if isinstance(value, dict):
            own_opers = value.get("own_opers")
            if isinstance(own_opers, list) and value.get("done", True):
                return value
            for child in value.values():
                found = find(child)
                if found is not None:
                    return found
        elif isinstance(value, list):
            for child in value:
                found = find(child)
                if found is not None:
                    return found
        return None

    result = None
    for event in events:
        found = find(event.details)
        if found is not None:
            result = found
    return result


class MaaCoreLibrary:
    """Load MaaCore.dll and declare only the exports needed by auto-push."""

    def __init__(self, dll_path: str | Path):
        self.path = Path(dll_path).resolve()
        if not self.path.is_file():
            raise FileNotFoundError(self.path)
        if hasattr(os, "add_dll_directory"):
            self._dll_directory = os.add_dll_directory(str(self.path.parent))
        else:
            self._dll_directory = None
        self.library = ctypes.CDLL(str(self.path))
        self._declare()

    def _declare(self) -> None:
        library = self.library
        library.AsstGetVersion.argtypes = []
        library.AsstGetVersion.restype = ctypes.c_char_p

        library.AsstSetUserDir.argtypes = [ctypes.c_char_p]
        library.AsstSetUserDir.restype = AsstBool

        library.AsstLoadResource.argtypes = [ctypes.c_char_p]
        library.AsstLoadResource.restype = AsstBool

        library.AsstCreateEx.argtypes = [AsstApiCallback, ctypes.c_void_p]
        library.AsstCreateEx.restype = AsstHandle

        library.AsstDestroy.argtypes = [AsstHandle]
        library.AsstDestroy.restype = None

        library.AsstConnect.argtypes = [
            AsstHandle,
            ctypes.c_char_p,
            ctypes.c_char_p,
            ctypes.c_char_p,
        ]
        library.AsstConnect.restype = AsstBool

        library.AsstAppendTask.argtypes = [
            AsstHandle,
            ctypes.c_char_p,
            ctypes.c_char_p,
        ]
        library.AsstAppendTask.restype = AsstTaskId

        library.AsstStart.argtypes = [AsstHandle]
        library.AsstStart.restype = AsstBool

        library.AsstStop.argtypes = [AsstHandle]
        library.AsstStop.restype = AsstBool

        library.AsstRunning.argtypes = [AsstHandle]
        library.AsstRunning.restype = AsstBool

        library.AsstConnected.argtypes = [AsstHandle]
        library.AsstConnected.restype = AsstBool

    def version(self) -> str:
        value = self.library.AsstGetVersion()
        return value.decode("utf-8", errors="replace") if value else ""


class MaaCoreSession:
    """Own one MAA Core instance and convert callbacks into local events."""

    def __init__(
        self,
        dll_path: str | Path,
        *,
        resource_dir: str | Path,
        user_dir: str | Path,
        metrics: RoundMetrics | None = None,
        event_sink: Callable[[MaaEvent], None] | None = None,
    ):
        self.metrics = metrics
        self._event_sink = event_sink
        self._events: list[MaaEvent] = []
        self._events_lock = threading.RLock()
        self._terminal_event = threading.Event()
        self._callback = AsstApiCallback(self._on_callback)
        self._library = MaaCoreLibrary(dll_path)

        if metrics is not None:
            metrics.record_tool_call(2)
        user = str(Path(user_dir).resolve()).encode("utf-8")
        resource_path = Path(resource_dir).resolve()
        # AsstLoadResource expects the directory that contains resource/, not
        # resource/ itself. Older callers passed the latter directly.
        resource_root = (
            resource_path.parent
            if resource_path.name.casefold() == "resource"
            else resource_path
        )
        resource = str(resource_root).encode("utf-8")
        if not self._library.library.AsstSetUserDir(user):
            raise MaaCoreError("AsstSetUserDir failed")
        if not self._library.library.AsstLoadResource(resource):
            raise MaaCoreError("AsstLoadResource failed")

        self.handle = self._library.library.AsstCreateEx(self._callback, None)
        if not self.handle:
            raise MaaCoreError("AsstCreateEx failed")

    @property
    def events(self) -> list[MaaEvent]:
        with self._events_lock:
            return list(self._events)

    def _on_callback(self, message_id: int, details: bytes | None, _: int) -> None:
        try:
            payload = json.loads(details.decode("utf-8")) if details else {}
        except (UnicodeDecodeError, json.JSONDecodeError):
            payload = {"raw": details.decode("utf-8", errors="replace")}
        event = MaaEvent(message_id=message_id, details=payload)
        with self._events_lock:
            self._events.append(event)
        terminal_what = payload.get("what")
        if terminal_what in {"AllTasksCompleted", "TaskChainError"}:
            self._terminal_event.set()
        if self._event_sink is not None:
            self._event_sink(event)

    def connect(
        self,
        *,
        adb_path: str | Path,
        address: str,
        config: str,
    ) -> None:
        if self.metrics is not None:
            self.metrics.record_tool_call()
        result = self._library.library.AsstConnect(
            self.handle,
            str(adb_path).encode("utf-8"),
            address.encode("utf-8"),
            config.encode("utf-8"),
        )
        if not result:
            raise MaaCoreError("AsstConnect failed")

    def append_task(self, task_type: str, parameters: dict[str, Any]) -> int:
        if self.metrics is not None:
            self.metrics.record_tool_call()
        task_id = self._library.library.AsstAppendTask(
            self.handle,
            task_type.encode("utf-8"),
            json.dumps(parameters, ensure_ascii=False).encode("utf-8"),
        )
        if task_id <= 0:
            raise MaaCoreError(f"AsstAppendTask failed for {task_type}")
        return int(task_id)

    def start(self) -> None:
        if self.metrics is not None:
            self.metrics.record_tool_call()
        self._terminal_event.clear()
        if not self._library.library.AsstStart(self.handle):
            raise MaaCoreError("AsstStart failed")

    def wait(self, timeout_seconds: int = 600) -> list[MaaEvent]:
        if self.metrics is not None:
            self.metrics.record_tool_call()
        deadline = time.monotonic() + timeout_seconds
        while time.monotonic() < deadline:
            if self._terminal_event.wait(0.5):
                break
            if not self._library.library.AsstRunning(self.handle):
                break
        else:
            raise TimeoutError("MAA Core task did not finish before timeout")
        return self.events

    def close(self) -> None:
        if getattr(self, "handle", None):
            if self.metrics is not None:
                self.metrics.record_tool_call()
            self._library.library.AsstDestroy(self.handle)
            self.handle = None

    def __enter__(self) -> MaaCoreSession:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


def run_copilot_file(
    *,
    dll_path: str | Path,
    resource_dir: str | Path,
    user_dir: str | Path,
    adb_path: str | Path,
    address: str,
    connect_config: str,
    copilot_file: str | Path,
    metrics: RoundMetrics,
    timeout_seconds: int = 600,
    exercise: bool = False,
) -> list[MaaEvent]:
    """Execute one local Copilot JSON and return all MAA callbacks."""

    metrics.consume("strategy_runs")
    task = {
        "filename": str(Path(copilot_file).resolve()),
        "formation": False,
        "exercise": exercise,
        "support_unit_usage": 0,
        "add_trust": False,
        "ignore_requirements": True,
        "use_sanity_potion": False,
        "loop_times": 1,
    }
    previous_priority = lower_current_process_priority()
    try:
        with MaaCoreSession(
            dll_path=dll_path,
            resource_dir=resource_dir,
            user_dir=user_dir,
            metrics=metrics,
        ) as session:
            session.connect(
                adb_path=adb_path,
                address=address,
                config=connect_config,
            )
            session.append_task("Copilot", task)
            session.start()
            return session.wait(timeout_seconds=timeout_seconds)
    finally:
        restore_current_process_priority(previous_priority)


def run_oper_box(
    *,
    dll_path: str | Path,
    resource_dir: str | Path,
    user_dir: str | Path,
    adb_path: str | Path,
    address: str,
    connect_config: str,
    metrics: RoundMetrics,
    timeout_seconds: int = 900,
) -> list[MaaEvent]:
    """Recognize the current roster through MAA's deterministic OperBox task."""

    previous_priority = lower_current_process_priority()
    try:
        with MaaCoreSession(
            dll_path=dll_path,
            resource_dir=resource_dir,
            user_dir=user_dir,
            metrics=metrics,
        ) as session:
            session.connect(
                adb_path=adb_path,
                address=address,
                config=connect_config,
            )
            session.append_task("OperBox", {})
            session.start()
            return session.wait(timeout_seconds=timeout_seconds)
    finally:
        restore_current_process_priority(previous_priority)
