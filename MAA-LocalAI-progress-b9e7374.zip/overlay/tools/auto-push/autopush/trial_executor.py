"""Injected trial executor connecting navigation, MAA and result verification."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np

from .maa_core import MaaEvent, summarize_events
from .trial import AttemptRecord, TrialAttempt, TrialScheduler
from .verifier import ResultVerification


@dataclass(frozen=True)
class TrialExecutionReport:
    completed: bool
    attempts: tuple[AttemptRecord, ...]
    stopped_reason: str


class TrialExecutor:
    """Run the bounded trial loop with injected local adapters."""

    def __init__(
        self,
        scheduler: TrialScheduler,
        *,
        prepare_stage: Callable[[TrialAttempt], None],
        run_copilot: Callable[[TrialAttempt], list[MaaEvent]],
        capture_result: Callable[[], np.ndarray],
        verify_result: Callable[[np.ndarray], ResultVerification],
        computer_use_verify: Callable[[], ResultVerification | None] | None = None,
    ):
        self.scheduler = scheduler
        self.prepare_stage = prepare_stage
        self.run_copilot = run_copilot
        self.capture_result = capture_result
        self.verify_result = verify_result
        self.computer_use_verify = computer_use_verify

    def run(self) -> TrialExecutionReport:
        stopped_reason = "attempt budget exhausted"
        while True:
            attempt = self.scheduler.next_attempt()
            if attempt is None:
                break
            self.prepare_stage(attempt)
            events = self.run_copilot(attempt)
            summary = summarize_events(events)
            if summary["task_errors"]:
                stopped_reason = "MaaCore task error"
                verification = ResultVerification(
                    status="unknown",
                    stars=None,
                    confidence=0.0,
                    evidence=(),
                    needs_computer_use=True,
                )
            else:
                verification = self.verify_result(self.capture_result())
                if (
                    verification.status == "unknown"
                    and self.computer_use_verify is not None
                    and self.scheduler.authorize_computer_use_for(verification)
                ):
                    fallback = self.computer_use_verify()
                    if fallback is not None:
                        verification = fallback

            self.scheduler.record_verification(verification)
            if self.scheduler.completed:
                stopped_reason = (
                    "three-star first clear"
                    if verification.status == "three_star"
                    else "verification limit reached"
                )
                break
        return TrialExecutionReport(
            completed=self.scheduler.completed,
            attempts=tuple(self.scheduler.attempts),
            stopped_reason=stopped_reason,
        )
