# MAA LocalAI Auto-Push Status

Updated: 2026-11-12

## Current milestone

The local workflow now covers roster recognition, exact-stage Copilot job
download, compatibility ranking, bounded ADB operations, MAA execution,
OpenCV result verification, and auditable per-round metrics.

## Implemented

- OpenAI-compatible local AI planner with loopback-only defaults and strict
  stage-plan validation.
- MAA `OperBox` recognition through the local C ABI adapter.
- Exact-stage PRTS Plus job queries with full action download.
- True-roster strategy compatibility ranking.
- ADB screenshot throttling, input helpers, visual state memory, and navigation
  preconditions.
- Trial scheduler that requires a three-star drill before a real run.
- Per-round records for Computer Use operations, screenshots, tool calls,
  DeepSeek input/output tokens, strategy runs, and test results.
- Python tests, LocalAI C# contract tests, WPF compile verification, VS Code
  tasks, and a Windows GitHub Actions validation workflow.

## TL-9 / EX progress

- Account roster recognized successfully: 328 owned operators.
- TL-9 and TL-EX-1 through TL-EX-8 job catalogs downloaded and ranked.
- TL-9 high-heat job `108702` matches owned operators, but its first runs failed
  result verification.
- The packaged `MaaCore.dll` predates the local exercise-mode patch. Until Core
  and resources are rebuilt and synchronized, automated trials can fall back to
  real battle behavior. No successful stage clear is claimed yet.
- The next milestone is to build and deploy the patched `MaaCore.dll`, verify
  that `exercise=true` selects the drill path, then resume with the strongest
  compatible TL-9 job before moving to EX stages.

## Safety boundaries

- Normal repeated input uses ADB or MAA, not model vision or per-frame analysis.
- Computer Use is recorded but does not cap the number of operations.
- Local automation must remain usable without Codex or an online model.
- A task completion callback is never treated as a three-star clear.
- Sanity potions and Originite Prime remain disabled unless explicitly enabled
  by the user.
