# LocalAI development workflow

`localai.ps1` is the single entry point for the local AI planner, Auto-Push tools,
the WPF build, and the low-resource runtime package.

Paths can be overridden with environment variables:

- `MAA_LOCALAI_PACKAGE_DIR`
- `MAA_LOCALAI_DOTNET`
- `MAA_LOCALAI_PYTHON`

## Daily commands

```powershell
cd D:\work\MaaAssistantArknights

# Check toolchain, package, Ollama model, ADB, and running processes.
powershell -NoProfile -ExecutionPolicy Bypass -File tools\localai-workflow\localai.ps1 doctor

# Run Python and C# tests plus a WPF compile check.
powershell -NoProfile -ExecutionPolicy Bypass -File tools\localai-workflow\localai.ps1 verify

# Faster focused checks.
powershell -NoProfile -ExecutionPolicy Bypass -File tools\localai-workflow\localai.ps1 test-python
powershell -NoProfile -ExecutionPolicy Bypass -File tools\localai-workflow\localai.ps1 test-dotnet

# Build the real Debug output after closing MAA.
powershell -NoProfile -ExecutionPolicy Bypass -File tools\localai-workflow\localai.ps1 build-gui

# Start only the UI and skip core initialization.
powershell -NoProfile -ExecutionPolicy Bypass -File tools\localai-workflow\localai.ps1 run-ui
```

## Validation matrix

| Change | Minimum validation |
| --- | --- |
| `tools/auto-push/**` | `test-python` |
| Local AI C# service, view model, XAML | `test-dotnet` and WPF build |
| `resource/tasks/tasks.json` | C# tests, Debug launch, task load check |
| `src/MaaCore/**` | Debug CMake build and the affected runtime flow |
| Packaging or launcher scripts | Compare source and package, then run a package smoke test |

`verify` intentionally writes to `build\workflow\verify` and disables the WPF
post-build resource link. This lets it run while another MAA package is open.

## Safety boundaries

- The model plan is untrusted input. Stage codes must match MAA's current catalog,
  contain no more than five stages, and use 1-99 clears.
- Loopback-only endpoints remain the default. Remote endpoints require an explicit
  user setting and must not be enabled in committed default configuration.
- Tests and workflow commands do not start, stop, or update MAA, MuMu, Ollama,
  or the game.
- User configuration, screenshots, reports, caches, and model files stay outside
  the repository and are never copied into test fixtures.
- The packaged application must not use MAA's built-in updater. Rebase the local
  extension onto a newer upstream version and rebuild instead.
