// <copyright file="FightTaskUserControlModel.cs" company="MaaAssistantArknights">
// Part of the MaaWpfGui project, maintained by the MaaAssistantArknights team (Maa Team)
// Copyright (C) 2021-2026 MaaAssistantArknights Contributors
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License v3.0 only as published by
// the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY
// </copyright>

#nullable enable
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using JetBrains.Annotations;
using MaaWpfGui.Configuration.Factory;
using MaaWpfGui.Configuration.Single.MaaTask;
using MaaWpfGui.Constants;
using MaaWpfGui.Constants.Enums;
using MaaWpfGui.Extensions;
using MaaWpfGui.Helper;
using MaaWpfGui.Main;
using MaaWpfGui.Models;
using MaaWpfGui.Models.AsstTasks;
using MaaWpfGui.States;
using MaaWpfGui.Utilities;
using MaaWpfGui.Utilities.ValueType;
using MaaWpfGui.ViewModels.UI;
using Newtonsoft.Json;
using ObservableCollections;
using Serilog;
using Stylet;
using static MaaWpfGui.Helper.Instances.Data;
using static MaaWpfGui.Main.AsstProxy;

namespace MaaWpfGui.ViewModels.UserControl.TaskQueue;

/// <summary>
/// 理智作战
/// </summary>
public partial class FightTaskUserControlModel : TaskSettingsViewModel, FightTaskUserControlModel.ISerialize
{
    public const string AnnihilationName = "Annihilation";
    private static readonly ILogger _logger = Log.ForContext<FightTaskUserControlModel>();
    private readonly RunningState _runningState;
    private readonly Lock _inventoryTargetRuntimeStateLock = new();
    private Dictionary<int, InventoryTargetRuntimeState> _inventoryTargetRuntimeStateByTaskId = [];

    public static FightTimes? FightReport { get; set; }

    public static SanityInfo? SanityReport { get; set; }

    static FightTaskUserControlModel()
    {
        Instance = new();
    }

    public FightTaskUserControlModel()
    {
        _runningState = RunningState.Instance;
        _runningState.StateChanged += OnRunningStateChanged;
        Instances.AsstProxy.OnTaskStatusChanged += OnTaskStatusChanged;
        Instances.AsstProxy.AsstSubTaskMsgEvent += ProcSubTaskMsg;

        if (Instances.ToolboxViewModel is { } toolboxViewModel)
        {
            toolboxViewModel.DepotResult.CollectionChanged += OnDepotResultCollectionChanged;
        }

        foreach (var i in WeeklyScheduleSource)
        {
            i.PropertyChanged += (_, __) => SaveWeeklySchedule();
        }
        var item = new StagePlanItem();
        item.PropertyChanged += (_, __) => SaveStagePlan();
        StagePlan.Add(item);
        InitDrops();

        // 本类型为 Instance 单例，构造仅执行一次，订阅后无需取消订阅
        LocalizationHelper.LanguageChanged += RefreshLocalization;
    }

    private void RefreshLocalization()
    {
        RebuildDropsList();
        SeriesList.RefreshLocalization();
        AnnihilationModeList.RefreshLocalization();
        StageResetModeList.RefreshLocalization();
        foreach (var item in WeeklyScheduleSource)
        {
            item.RefreshLocalization();
        }
    }

    /// <summary>
    /// 当队列进入或离开空闲状态时，清理按任务保存的目标库存运行时状态。
    /// </summary>
    private void OnRunningStateChanged(object? sender, RunningState.RunningStateChangedEventArgs e)
    {
        if (e.NewState.Idle == e.OldState.Idle)
        {
            return;
        }

        ResetInventoryTargetRuntimeState();
    }

    /// <summary>
    /// 重置各作战任务启动时捕获的目标库存运行时缓存。
    /// </summary>
    private void ResetInventoryTargetRuntimeState()
    {
        lock (_inventoryTargetRuntimeStateLock)
        {
            _inventoryTargetRuntimeStateByTaskId = [];
        }

        Execute.OnUIThread(NotifySpecifiedDropsStateChanged);
    }

    /// <summary>
    /// 当指定掉落的作战任务完成时记录临期药耗尽证明；进入进行中状态时，用最新库存重算指定掉落缺口并更新参数。
    /// </summary>
    private void OnTaskStatusChanged(int taskId, TaskItemStatus status)
    {
        if (taskId <= 0)
        {
            return;
        }

        if (status == TaskItemStatus.Completed)
        {
            // 有次数限制的目标库存任务可能打满次数而未达标，结束原因不唯一，不构成耗尽证明；
            // 无次数限制时该模式下 ｢未达库存目标的正常结束｣ 只能是理智不足
            if (GetFightTaskByTaskId(taskId) is { } completedFight &&
                IsInventoryTargetDropEnabled(completedFight) &&
                !string.IsNullOrEmpty(completedFight.DropId) &&
                (completedFight.EnableTimesLimit == false || completedFight.TimesLimit == int.MaxValue))
            {
                UpdateProvenExhaustedMedicineDays(
                    completedFight.UseExpiringMedicine ? completedFight.MedicineExpireDays : 0,
                    completedFight.DropId,
                    completedFight.DropCount);
            }

            return;
        }

        if (status != TaskItemStatus.InProgress)
        {
            return;
        }

        if (GetFightTaskByTaskId(taskId) is { } startedFight &&
            IsInventoryTargetDropEnabled(startedFight) &&
            !string.IsNullOrEmpty(startedFight.DropId))
        {
            // 每次任务开始时用最新库存重算缺口（前序任务可能已经刷出了该材料）
            var stage = GetFightStage(startedFight.StagePlan);
            if (!string.IsNullOrEmpty(stage))
            {
                // 与 append 序列化共用构建方法与次数口径（或门：次数限制与库存目标先到先停），
                // 库存已达标时由 RefreshFightTaskDrops 置 0 跳过
                var maxTimes = startedFight.EnableTimesLimit != false ? startedFight.TimesLimit : int.MaxValue;
                var task = BuildAsstFightTask(startedFight, stage, maxTimes);
                RefreshFightTaskDrops(taskId, startedFight.DropId, startedFight.DropCount, startedFight.NameOrTaskType, task);
            }
        }

        Execute.OnUIThread(() => {
            if (TaskSettingVisibilityInfo.CurrentTask is not FightTask currentFight || !IsInventoryTargetDropEnabled(currentFight))
            {
                return;
            }

            int currentIndex = TaskSettingVisibilityInfo.Instance.CurrentIndex;
            if (currentIndex < 0 || currentIndex >= Instances.TaskQueueViewModel.TaskItemViewModels.Count)
            {
                return;
            }

            if (!Instances.TaskQueueViewModel.TaskItemViewModels[currentIndex].TaskIds.Contains(taskId))
            {
                return;
            }

            NotifySpecifiedDropsStateChanged();
        });
    }

    /// <summary>
    /// 当仓库识别数据变化时，刷新界面显示的目标库存信息。
    /// </summary>
    private void OnDepotResultCollectionChanged(in NotifyCollectionChangedEventArgs<ToolboxViewModel.DepotResultDate> e)
    {
        _ = e;
        if (!_runningState.Idle)
        {
            return;
        }

        Execute.OnUIThread(NotifySpecifiedDropsStateChanged);
    }

    public static FightTaskUserControlModel Instance { get; }

    /// <summary>
    /// Gets or sets a value indicating whether 关卡规划项正在被拖拽。
    /// </summary>
    public bool IsStageItemDragging { get => field; set => SetAndNotify(ref field, value); }

    /// <summary>
    /// Gets or private sets a value indicating whether 关卡列表。
    /// </summary>
    public ObservableCollection<StageSourceItem> StageListSource { get => field; private set => SetAndNotify(ref field, value); } = [];

    private static readonly Dictionary<string, string> _stageDictionary = new()
        {
            { "AN", AnnihilationName },
            { "剿灭", AnnihilationName },
            { "CE", "CE-6" },
            { "龙门币", "CE-6" },
            { "LS", "LS-6" },
            { "经验", "LS-6" },
            { "狗粮", "LS-6" },
            { "CA", "CA-5" },
            { "技能", "CA-5" },
            { "AP", "AP-5" },
            { "红票", "AP-5" },
            { "SK", "SK-5" },
            { "碳", "SK-5" },
            { "炭", "SK-5" },
        };

    /* private readonly StageSourceItem InvalidStage = new() { Display = LocalizationHelper.GetString("InvalidStage"), Value = "__INVALID__", IsOpen = false, IsVisible = false };*/

    public ObservableCollection<StagePlanItem> StagePlan { get => field; set => SetAndNotify(ref field, value); } = [];

    // UI 绑定的方法
    [UsedImplicitly]
    public void AddStageToPlan()
    {
        var item = new StagePlanItem();
        item.PropertyChanged += (_, __) => SaveStagePlan();
        StagePlan.Add(item);
    }

    /// <summary>
    /// Applies a validated local-model stage plan to the currently selected Fight task.
    /// </summary>
    /// <param name="stageCodes">Exact stage codes to place in the plan.</param>
    /// <param name="times">Requested clear count.</param>
    /// <returns>Success state and a localization key describing the result.</returns>
    public (bool Success, string MessageKey) TryApplyLocalAiStagePlan(
        IReadOnlyList<string> stageCodes,
        int times)
    {
        if (!_runningState.Idle)
        {
            return (false, "LocalAi.Apply.Running");
        }

        if (TaskSettingVisibilityInfo.CurrentTask is not FightTask fight)
        {
            return (false, "LocalAi.Apply.NoFightTask");
        }

        if (stageCodes.Count == 0)
        {
            return (false, "LocalAi.Apply.NoStageSelected");
        }

        HashSet<string> openStages = Instances.StageManager
            .GetStageList(Instances.TaskQueueViewModel.CurDayOfWeek)
            .Select(stage => stage.Value)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        if (stageCodes.Any(stage => !openStages.Contains(stage)))
        {
            return (false, "LocalAi.Apply.StageUnavailable");
        }

        fight.StagePlan = [.. stageCodes];
        fight.UseOptionalStage = stageCodes.Count > 1;
        fight.IsStageManually = false;
        fight.EnableTimesLimit = true;
        fight.TimesLimit = Math.Clamp(times, 1, 99);
        fight.UseMedicine = false;
        fight.UseStone = false;
        RefreshUI(fight);
        return (true, "LocalAi.Apply.Success");
    }

    /// <summary>
    /// README 截图演示模式专用：绕开联网关卡更新与当日开放过滤，切至备选关卡模式，
    /// 并以给定关卡名重建候选关卡列表与已选关卡。
    /// 语言切换会经 <see cref="UpdateStageList"/> 重建列表，届时需重新调用本方法。
    /// </summary>
    /// <param name="stages">候选关卡名；Display/Value 取 <see cref="MaaWpfGui.Services.StageManager.GetStageInfo"/> 的解析结果（含兜底）。</param>
    public void InjectDemoStages(IReadOnlyList<string> stages)
    {
        if (TaskSettingVisibilityInfo.CurrentTask is not FightTask current)
        {
            _logger.Warning("InjectDemoStages skipped: current task is not FightTask");
            return;
        }

        // 备选三行 StagePlan 不受 UseAlternateStage 控制可见性，必须先切备选模式，
        // 否则 ｢关卡指定｣ 标签/添加关卡按钮/复选框勾选停留在主关卡模式，与渲染出的三行叠加错乱
        UseAlternateStage = true;

        StageListSource = [.. stages.Select(s => {
            var info = Instances.StageManager.GetStageInfo(s);
            return new StageSourceItem { Display = info.Display, Value = info.Value, IsOpen = true, IsVisible = true };
        })];
        current.StagePlan = [.. stages.Select(s => Instances.StageManager.GetStageInfo(s).Value)];
        RefreshCurrentStagePlan();

        // 演示截图不校验当日开放，勾掉关卡行的删除线样式
        foreach (var item in StagePlan)
        {
            item.IsOpen = true;
        }

        // 注入后校验末位落位，自检 GetStageInfo 解析与注入赋值的一致性；截图前若被异步重建覆盖，需另从日志比对发现
        if (StageListSource.Count == 0)
        {
            _logger.Warning("Demo stage injection produced empty stage list");
            return;
        }

        if (StageListSource[^1].Value != Instances.StageManager.GetStageInfo(stages[^1]).Value)
        {
            _logger.Warning("Demo stage injection mismatch: last item is {Actual}, expected {Expected}", StageListSource[^1].Value, stages[^1]);
        }
        else
        {
            _logger.Information("Demo stages injected: {Count} item(s), last={LastDisplay}", StageListSource.Count, StageListSource[^1].Display);
        }
    }

    /// <summary>
    /// README 截图演示模式专用：设置 ｢指定材料｣ 下拉显示的材料，不勾选 ｢指定材料｣（避免带出数量框）。
    /// 语言切换经 <see cref="RebuildDropsList"/> 自动保留选中并刷新显示名，随语言组重复调用幂等。
    /// </summary>
    /// <param name="itemId">材料 ID（resource/item_index.json 的 key，如 30012 固源岩）。</param>
    public void InjectDemoSpecifiedDrops(string itemId)
    {
        if (TaskSettingVisibilityInfo.CurrentTask is not FightTask)
        {
            _logger.Warning("InjectDemoSpecifiedDrops skipped: current task is not FightTask");
            return;
        }

        if (AllDrops.All(i => i.Value != itemId))
        {
            _logger.Warning("Demo specified drops item {ItemId} not in drops list, skipped", itemId);
            return;
        }

        DropsItemId = itemId;
        RefreshDropName();
    }

    // UI 绑定的方法
    [UsedImplicitly]
    public void RemoveStageFromPlan(StagePlanItem plan)
    {
        if (StagePlan.Count == 1)
        {
            _logger.Warning("Attempted to remove the last stage from the plan. Operation aborted.");
            return;
        }

        StagePlan.Remove(plan);
    }

    /// <summary>
    /// Gets or sets a value indicating whether 使用自定义关卡代码。
    /// </summary>
    public bool CustomStageCode
    {
        get => GetTaskConfig<FightTask>().IsStageManually;
        set {
            bool ret = SetTaskConfig<FightTask>(t => t.IsStageManually == value, t => t.IsStageManually = value);
            if (ret && !value)
            {
                var stagePlan = GetTaskConfig<FightTask>().StagePlan;
                for (int i = 0; i < stagePlan.Count; i++)
                {
                    var stage = stagePlan[i];
                    if (!Instances.StageManager.GetStageList().Any(p => p.Value == stage))
                    {
                        stagePlan[i] = string.Empty;
                    }
                }
                SetTaskConfig<FightTask>(t => t.StagePlan.SequenceEqual(stagePlan), t => t.StagePlan = stagePlan);
                RefreshCurrentStagePlan();
            }
        }
    }

    /// <summary>
    /// 重置未保存的作战参数。
    /// </summary>
    /// <param name="fight">作战任务配置。</param>
    public static void ResetFightVariables(FightTask? fight)
    {
        fight?.UseStone ??= false;
        fight?.UseMedicine ??= false;
        fight?.EnableTimesLimit ??= false;
        fight?.EnableTargetDrop ??= false;
    }

    /// <summary>
    /// Gets or sets a value indicating whether 使用理智药。
    /// </summary>
    public bool? UseMedicine
    {
        get => GetTaskConfig<FightTask>().UseMedicine;
        set {
            if (!SetTaskConfig<FightTask>(t => t.UseMedicine == value, t => t.UseMedicine = value))
            {
                return;
            }

            if (value == false)
            {
                UseStoneDisplay = false;
            }

            SetFightParams();
        }
    }

    /// <summary>
    /// Gets or sets 使用理智药数量。
    /// </summary>
    public int MedicineNumber
    {
        get => GetTaskConfig<FightTask>().MedicineCount;
        set {
            if (!SetTaskConfig<FightTask>(t => t.MedicineCount == value, t => t.MedicineCount = value))
            {
                return;
            }

            SetFightParams();
        }
    }

    /// <summary>
    /// Gets or sets a value indicating whether 使用源石。
    /// </summary>
    public bool? UseStone
    {
        get => GetTaskConfig<FightTask>().UseStone;
        set {
            if (!AllowUseStoneSave && value == true)
            {
                value = null;
            }

            if (value != false)
            {
                MedicineNumber = 999;
                if (UseMedicine == false)
                {
                    UseMedicine = value;
                }
            }

            SetFightParams();
            SetTaskConfig<FightTask>(t => t.UseStone == value, t => t.UseStone = value);
        }
    }

    /// <summary>
    /// Gets or sets a value indicating whether 使用源石 with null
    /// </summary>
    [PropertyDependsOn(nameof(UseStone))]
    public bool UseStoneDisplay
    {
        get => UseStone != false;
        set => UseStone = value;
    }

    /// <summary>
    /// Gets or sets 使用源石数量。
    /// </summary>
    public int StoneNumber
    {
        get => GetTaskConfig<FightTask>().StoneCount;
        set {
            if (!SetTaskConfig<FightTask>(t => t.StoneCount == value, t => t.StoneCount = value))
            {
                return;
            }

            SetFightParams();
        }
    }

    /// <summary>
    /// Gets or sets a value indicating whether 限制次数 with null
    /// </summary>
    public bool? HasTimesLimited
    {
        get => GetTaskConfig<FightTask>().EnableTimesLimit;
        set {
            if (!SetTaskConfig<FightTask>(t => t.EnableTimesLimit == value, t => t.EnableTimesLimit = value))
            {
                return;
            }

            SetFightParams();
        }
    }

    /// <summary>
    /// Gets or sets 最大次数。
    /// </summary>
    public int MaxTimes
    {
        get => GetTaskConfig<FightTask>().TimesLimit;
        set {
            if (!SetTaskConfig<FightTask>(t => t.TimesLimit == value, t => t.TimesLimit = value))
            {
                return;
            }

            SetFightParams();
        }
    }

    public LocalizedObservableList<int> SeriesList { get; } = new(
        (0, "AUTO"),
        (10, "10"),
        (9, "9"),
        (8, "8"),
        (7, "7"),
        (6, "6"),
        (5, "5"),
        (4, "4"),
        (3, "3"),
        (2, "2"),
        (1, "1"),
        (-1, "TaskQueue.NotSwitch"));

    /// <summary>
    /// Gets or sets 连战次数。
    /// </summary>
    public int Series
    {
        get => GetTaskConfig<FightTask>().Series;

        set {
            if (SetTaskConfig<FightTask>(t => t.Series == value, t => t.Series = value))
            {
                SetFightParams();
            }
        }
    }

    #region Drops

    /// <summary>
    /// Gets or sets a value indicating whether 启用指定材料。
    /// </summary>
    public bool? IsSpecifiedDrops
    {
        get => GetTaskConfig<FightTask>().EnableTargetDrop;
        set {
            if (IsSpecifiedInventoryLocked)
            {
                return;
            }

            if (!SetTaskConfig<FightTask>(t => t.EnableTargetDrop == value, t => t.EnableTargetDrop = value))
            {
                return;
            }

            SetFightParams();
        }
    }

    /// <summary>
    /// Gets or sets a value indicating whether 指定材料按目标库存模式计算。
    /// </summary>
    public bool UseInventoryTarget
    {
        get => GetTaskConfig<FightTask>().IsInventoryTarget;
        set {
            if (!_runningState.Idle)
            {
                return;
            }

            if (!SetTaskConfig<FightTask>(t => t.IsInventoryTarget == value, t => t.IsInventoryTarget = value))
            {
                return;
            }

            NotifySpecifiedDropsStateChanged();
            SetFightParams();
        }
    }

    public bool IsSpecifiedInventoryLocked => UseInventoryTarget && !_runningState.Idle;

    public bool UseDropQuantityMode
    {
        get => !UseInventoryTarget;
        set {
            if (value)
            {
                UseInventoryTarget = false;
            }
        }
    }

    public bool UseTargetInventoryMode
    {
        get => UseInventoryTarget;
        set {
            if (value)
            {
                UseInventoryTarget = true;
            }
        }
    }

    public string CurrentDropsInventoryText => FormatSpecifiedDropsCount(GetSpecifiedDropsInventoryCount(GetTaskConfig<FightTask>(), GetCurrentFightTaskId()));

    public string EffectiveDropsQuantityText => FormatSpecifiedDropsCount(GetSpecifiedDropsCoreQuantity(GetTaskConfig<FightTask>(), GetCurrentFightTaskId()));

    private static string FormatSpecifiedDropsCount(int? count) => count is int value ? value.FormatNumber(false) : "--";

    private static bool IsInventoryTargetDropEnabled(FightTask fight)
    {
        return fight.EnableTargetDrop != false && !string.IsNullOrEmpty(fight.DropId) && fight.IsInventoryTarget;
    }

    /// <summary>
    /// 获取当前选中作战任务绑定的第一个 core task id。
    /// </summary>
    private static int? GetCurrentFightTaskId()
    {
        if (TaskSettingVisibilityInfo.CurrentTask is not FightTask fight)
        {
            return null;
        }

        int index = ConfigFactory.CurrentConfig.TaskQueue.IndexOf(fight);
        if (index < 0 || index >= Instances.TaskQueueViewModel.TaskItemViewModels.Count)
        {
            return null;
        }

        var taskIds = Instances.TaskQueueViewModel.TaskItemViewModels[index].TaskIds;
        return taskIds.Count > 0 ? taskIds[0] : null;
    }

    /// <summary>
    /// 根据 core task id 反查对应的作战任务配置。
    /// </summary>
    private static FightTask? GetFightTaskByTaskId(int taskId)
    {
        if (taskId <= 0)
        {
            return null;
        }

        for (int index = 0; index < Instances.TaskQueueViewModel.TaskItemViewModels.Count; ++index)
        {
            if (!Instances.TaskQueueViewModel.TaskItemViewModels[index].TaskIds.Contains(taskId))
            {
                continue;
            }

            return index < ConfigFactory.CurrentConfig.TaskQueue.Count
                ? ConfigFactory.CurrentConfig.TaskQueue[index] as FightTask
                : null;
        }

        return null;
    }

    /// <summary>
    /// 检查指定 core 作战任务是否已在运行。
    /// </summary>
    private static bool IsTaskInProgress(int taskId)
    {
        return taskId > 0 &&
               Instances.AsstProxy.TasksStatus.TryGetValue(taskId, out var taskState) &&
               taskState.Status == MaaWpfGui.Main.TaskStatus.InProgress;
    }

    /// <summary>
    /// 获取指定 core 任务缓存的目标库存运行时状态。
    /// </summary>
    private InventoryTargetRuntimeState? GetInventoryTargetRuntimeState(int? taskId)
    {
        if (taskId is not int id || id <= 0)
        {
            return null;
        }

        lock (_inventoryTargetRuntimeStateLock)
        {
            return _inventoryTargetRuntimeStateByTaskId.GetValueOrDefault(id);
        }
    }

    /// <summary>
    /// 获取指定掉落目标显示的库存数量。任务开始后，该显示值会被冻结。
    /// </summary>
    private int? GetSpecifiedDropsInventoryCount(FightTask fight, int? taskId = null)
    {
        if (string.IsNullOrEmpty(fight.DropId))
        {
            return null;
        }

        if (GetInventoryTargetRuntimeState(taskId) is { } runtimeState && runtimeState.DropId == fight.DropId)
        {
            return runtimeState.StartInventory;
        }

        var currentInventoryCounts = Instances.ToolboxViewModel?.GetDepotSnapshot();
        if (currentInventoryCounts == null)
        {
            return null;
        }

        return currentInventoryCounts.TryGetValue(fight.DropId, out var count) ? count : 0;
    }

    /// <summary>
    /// 获取指定目标库存任务显示并下发给 core 的实际刷取数量。
    /// </summary>
    private int? GetSpecifiedDropsCoreQuantity(FightTask fight, int? taskId = null)
    {
        if (!IsInventoryTargetDropEnabled(fight))
        {
            return fight.DropCount;
        }

        if (GetInventoryTargetRuntimeState(taskId) is { } runtimeState)
        {
            return runtimeState.EffectiveQuantity;
        }

        int? inventoryCount = GetSpecifiedDropsInventoryCount(fight);
        if (inventoryCount is not int currentInventory)
        {
            return null;
        }

        return Math.Max(fight.DropCount - currentInventory, 0);
    }

    /// <summary>
    /// 捕获运行中作战任务需要保持固定的目标库存值。
    /// </summary>
    private static InventoryTargetRuntimeState? CreateInventoryTargetRuntimeState(FightTask fight)
    {
        var currentInventoryCounts = Instances.ToolboxViewModel?.GetDepotSnapshot();
        if (currentInventoryCounts == null)
        {
            return null;
        }

        int startInventory = currentInventoryCounts.GetValueOrDefault(fight.DropId);
        int effectiveQuantity = Math.Max(fight.DropCount - startInventory, 0);
        return new(fight.DropId, startInventory, effectiveQuantity);
    }

    /// <summary>
    /// 在捕获启动时的目标库存值后，保存该 core 作战任务的运行时状态。
    /// </summary>
    private void RememberInventoryTargetRuntimeState(int taskId, InventoryTargetRuntimeState runtimeState)
    {
        if (taskId <= 0)
        {
            return;
        }

        lock (_inventoryTargetRuntimeStateLock)
        {
            _inventoryTargetRuntimeStateByTaskId[taskId] = runtimeState;
        }
    }

    /// <summary>
    /// 刷新目标库存模式及其显示数量相关的 UI 绑定。
    /// </summary>
    private void NotifySpecifiedDropsStateChanged()
    {
        NotifyOfPropertyChange(nameof(IsSpecifiedInventoryLocked));
        NotifyOfPropertyChange(nameof(UseDropQuantityMode));
        NotifyOfPropertyChange(nameof(UseTargetInventoryMode));
        NotifyOfPropertyChange(nameof(CurrentDropsInventoryText));
        NotifyOfPropertyChange(nameof(EffectiveDropsQuantityText));
    }

    /// <summary>
    /// Gets 全部掉落材料列表。
    /// </summary>
    private List<CombinedData> AllDrops { get; } = [];

    /// <summary>
    /// 关卡不可掉落的材料
    /// </summary>
    private static readonly HashSet<string> _excludedValues =
    [
        "3213", "3223", "3233", "3243", // 双芯片
        "3253", "3263", "3273", "3283", // 双芯片
        "7001", "7002", "7003", "7004", // 许可
        "4004", "4005", // 凭证
        "3105", "3131", "3132", "3133", // 龙骨/加固建材
        "6001", // 演习券
        "3141", "4002", // 源石
        "32001", // 芯片助剂
        "30115", // 聚合剂
        "30125", // 双极纳米片
        "30135", // D32钢
        "30145", // 晶体电子单元
        "30155", // 烧结核凝晶
        "30165", // 重相位对映体
    ];

    private void InitDrops()
    {
        AllDrops.Add(new() { Display = LocalizationHelper.GetString("Common.NotSelected"), Value = string.Empty });
        foreach (var (val, value) in ItemListHelper.ArkItems)
        {
            // 不是数字的东西都是正常关卡不会掉的（大概吧）
            if (!int.TryParse(val, out _))
            {
                continue;
            }

            var dis = value.Name;

            if (_excludedValues.Contains(val))
            {
                continue;
            }

            AllDrops.Add(new() { Display = dis, Value = val });
        }

        AllDrops.Sort((a, b) => string.Compare(a.Value, b.Value, StringComparison.Ordinal));

        // 原地更新 DropsList：只更新 Display 不增删项，避免 ComboBox SelectedValue 丢失
        // 首次构建时 DropsList 为空，需要完整 Add；后续语言切换时只更新 Display
        var allDropsDict = AllDrops.ToDictionary(i => i.Value, i => i.Display);
        if (DropsList.Count == 0)
        {
            foreach (var item in AllDrops)
            {
                DropsList.Add(item);
            }
        }
        else
        {
            // 更新已有项的 Display
            foreach (var item in DropsList)
            {
                if (allDropsDict.TryGetValue(item.Value, out var newDisplay))
                {
                    item.Display = newDisplay;
                }
            }

            // 补充新出现的项（如特有材料）
            var existingValues = DropsList.Select(i => i.Value).ToHashSet();
            foreach (var item in AllDrops.Where(i => !existingValues.Contains(i.Value)))
            {
                DropsList.Add(item);
            }

            // 删除不再存在的项（保留空值项即"不选择"）
            for (int i = DropsList.Count - 1; i >= 0; i--)
            {
                if (!string.IsNullOrEmpty(DropsList[i].Value) && !allDropsDict.ContainsKey(DropsList[i].Value))
                {
                    DropsList.RemoveAt(i);
                }
            }
        }

        foreach (var task in ConfigFactory.CurrentConfig.TaskQueue.OfType<FightTask>())
        {
            if (AllDrops.FirstOrDefault(i => i.Value == task.DropId) is not { } item)
            {
                task.DropId = string.Empty;
            }
        }
    }

    /// <summary>
    /// Gets 获取或私有设置掉落材料列表。
    /// </summary>
    public ObservableCollection<CombinedData> DropsList { get; private set; } = [];

    /// <summary>
    /// 语言切换时重建掉落材料列表。
    /// </summary>
    private void RebuildDropsList()
    {
        // 提前记录当前选中的掉落 ID，避免重建后丢失
        var savedDropId = GetTaskConfig<FightTask>().DropId;
        ItemListHelper.Reload();
        AllDrops.Clear();
        InitDrops();

        // 恢复选中状态
        if (!string.IsNullOrEmpty(savedDropId) && AllDrops.Any(i => i.Value == savedDropId))
        {
            SetTaskConfig<FightTask>(t => t.DropId == savedDropId, t => t.DropId = savedDropId);
        }

        RefreshDropName();

        // 通知 DepotMaintain 刷新各 plan 的 DropName
        DepotMaintainTaskUserControlModel.Instance.OnLanguageChanged();
    }

    /// <summary>
    /// Gets or sets 指定掉落材料 ID。
    /// </summary>
    public string DropsItemId
    {
        get => GetTaskConfig<FightTask>().DropId;
        set {
            if (IsSpecifiedInventoryLocked)
            {
                return;
            }

            if (!SetTaskConfig<FightTask>(t => t.DropId == value, t => t.DropId = value))
            {
                return;
            }

            NotifySpecifiedDropsStateChanged();
            SetFightParams();
        }
    }

    /// <summary>
    /// Gets or sets 指定掉落材料名称。
    /// </summary>
    public string DropsItemName { get => field; set => SetAndNotify(ref field, value); } = string.Empty;

    // UI 绑定的方法
    [UsedImplicitly]
    public void DropsListDropDownClosed()
    {
        if (IsSpecifiedInventoryLocked)
        {
            RefreshDropName();
            NotifySpecifiedDropsStateChanged();
            return;
        }

        if (DropsList.FirstOrDefault(i => i.Display == DropsItemName) is { } item)
        {
            DropsItemId = item.Value;
        }
        else
        {
            DropsItemId = string.Empty;
            DropsItemName = LocalizationHelper.GetString("Common.NotSelected");
            NotifyOfPropertyChange(nameof(DropsItemName));
        }
    }

    /// <summary>
    /// Gets or sets 指定掉落数量。
    /// </summary>
    public int DropsQuantity
    {
        get => GetTaskConfig<FightTask>().DropCount;
        set {
            if (IsSpecifiedInventoryLocked)
            {
                return;
            }

            if (!SetTaskConfig<FightTask>(t => t.DropCount == value, t => t.DropCount = value))
            {
                return;
            }

            NotifySpecifiedDropsStateChanged();
            SetFightParams();
        }
    }

    #endregion Drops

    public string StagePlanTip { get => field; set => SetAndNotify(ref field, value); } = string.Empty;

    public void StagePlanTipRefresh()
    {
        var stage = GetFightStage(StagePlan.Select(i => i.Stage)) ?? "--";
        if (stage == string.Empty)
        {
            stage = LocalizationHelper.GetString("TaskQueue.Stage.Label.Default");
        }

        StagePlanTip = LocalizationHelper.GetStringFormat("TaskQueue.Fight.StagePlan.Tip", stage);
        if (CustomStageCode)
        {
            StagePlanTip += $"\n\n{LocalizationHelper.GetString("TaskQueue.CustomStageCode.Tip")}";
        }
    }

    public LocalizedObservableList<string> AnnihilationModeList { get; } = new(
        (AnnihilationName, "TaskQueue.Annihilation.Current"),
        ("Chernobog@Annihilation", "TaskQueue.Annihilation.Chernobog"),
        ("LungmenOutskirts@Annihilation", "TaskQueue.Annihilation.LungmenOutskirts"),
        ("LungmenDowntown@Annihilation", "TaskQueue.Annihilation.LungmenDowntown"));

    public bool UseCustomAnnihilation
    {
        get => GetTaskConfig<FightTask>().UseCustomAnnihilation;
        set {
            bool ret = SetTaskConfig<FightTask>(t => t.UseCustomAnnihilation == value, t => t.UseCustomAnnihilation = value);
            if (ret)
            {
                StageListSource.FirstOrDefault(i => i.Value == AnnihilationName)?.Display =
                    UseCustomAnnihilation
                        ? (AnnihilationModeList.FirstOrDefault(i => i.Value == AnnihilationStage)?.Display
                            ?? LocalizationHelper.GetString("TaskQueue.Annihilation.Current"))
                        : LocalizationHelper.GetString("TaskQueue.Annihilation.Current");
            }
        }
    }

    public string AnnihilationStage
    {
        get => GetTaskConfig<FightTask>().AnnihilationStage;
        set {
            SetTaskConfig<FightTask>(t => t.AnnihilationStage == value, t => t.AnnihilationStage = value);
            StageListSource.FirstOrDefault(i => i.Value == AnnihilationName)?.Display =
                UseCustomAnnihilation
                    ? (AnnihilationModeList.FirstOrDefault(i => i.Value == value)?.Display
                        ?? LocalizationHelper.GetString("TaskQueue.Annihilation.Current"))
                    : LocalizationHelper.GetString("TaskQueue.Annihilation.Current");
        }
    }

    /// <summary>
    /// Gets or sets a value indicating whether 启用 DrGrandet 模式。
    /// </summary>
    public bool IsDrGrandet
    {
        get => GetTaskConfig<FightTask>().IsDrGrandet;
        set => SetTaskConfig<FightTask>(t => t.IsDrGrandet == value, t => t.IsDrGrandet = value);
    }

    /// <summary>
    /// Gets or sets a value indicating whether 使用备选关卡。
    /// </summary>
    public bool UseAlternateStage
    {
        get => GetTaskConfig<FightTask>().UseOptionalStage;
        set {
            SetTaskConfig<FightTask>(t => t.UseOptionalStage == value, t => t.UseOptionalStage = value);
            if (value)
            {
                HideUnavailableStage = false;
                StageResetMode = FightStageResetMode.Ignore;
            }
            else
            {
                var list = StagePlan;
                if (list.Count == 0)
                {
                    var item = new StagePlanItem();
                    item.PropertyChanged += (_, __) => SaveStagePlan();
                    StagePlan.Add(item);
                }
                else
                {
                    var stage = list[0];
                    StagePlan.Clear();
                    StagePlan.Add(stage);
                }
            }
        }
    }

    public bool AllowUseStoneSave
    {
        get => GetTaskConfig<FightTask>().UseStoneAllowSave;
        set {
            if (value)
            {
                var result = MessageBoxHelper.Show(
                    LocalizationHelper.GetString("TaskQueue.Fight.AllowUseStoneSave.Warning"),
                    LocalizationHelper.GetString("Common.Warning"),
                    MessageBoxButton.OKCancel,
                    MessageBoxImage.Warning,
                    ok: LocalizationHelper.GetString("Common.Confirm"),
                    cancel: LocalizationHelper.GetString("Common.Cancel"),
                    iconBrushKey: "DangerBrush",
                    defaultResult: MessageBoxResult.Cancel);
                if (result != MessageBoxResult.OK)
                {
                    return;
                }
            }

            SetTaskConfig<FightTask>(t => t.UseStoneAllowSave == value, t => t.UseStoneAllowSave = value);
        }
    }

    public bool UseExpiringMedicine
    {
        get => GetTaskConfig<FightTask>().UseExpiringMedicine;
        set {
            SetTaskConfig<FightTask>(t => t.UseExpiringMedicine == value, t => t.UseExpiringMedicine = value);
            SetFightParams();
        }
    }

    public int MedicineExpireDays
    {
        get => GetTaskConfig<FightTask>().MedicineExpireDays;
        set {
            SetTaskConfig<FightTask>(t => t.MedicineExpireDays == value, t => t.MedicineExpireDays = value);
            SetFightParams();
        }
    }

    public bool UseExpireMedicineForActivity
    {
        get => GetTaskConfig<FightTask>().UseExpireMedicineForActivity;
        set {
            SetTaskConfig<FightTask>(t => t.UseExpireMedicineForActivity == value, t => t.UseExpireMedicineForActivity = value);
            SetFightParams();
        }
    }

    public bool ActivityExpireIn2Days { get => field; set => SetAndNotify(ref field, value); }

    public string ActivityInfo { get => field; private set => SetAndNotify(ref field, value); } = string.Empty;

    /// <summary>
    /// Gets or sets a value indicating whether 隐藏未开放关卡。
    /// </summary>
    public bool HideUnavailableStage
    {
        get => GetTaskConfig<FightTask>().HideUnavailableStage;
        set {
            var update = SetTaskConfig<FightTask>(t => t.HideUnavailableStage == value, t => t.HideUnavailableStage = value);

            if (value)
            {
                UseAlternateStage = false;
                StageResetMode = FightStageResetMode.Current;
            }
            if (update)
            {
                RefreshStageList();
                RefreshCurrentStagePlan(); // 这个刷新可以优化
            }
        }
    }

    public LocalizedObservableList<FightStageResetMode> StageResetModeList { get; } = new(
        (FightStageResetMode.Current, "TaskQueue.Stage.Label.Default"),
        (FightStageResetMode.Ignore, "TaskQueue.NotSwitch"));

    public FightStageResetMode StageResetMode
    {
        get => GetTaskConfig<FightTask>().StageResetMode;
        set => SetTaskConfig<FightTask>(t => t.StageResetMode == value, t => t.StageResetMode = value);
    }

    /// <summary>
    /// Gets or sets a value indicating whether 隐藏连战设置。
    /// </summary>
    public bool HideSeries
    {
        get => GetTaskConfig<FightTask>().HideSeries;
        set => SetTaskConfig<FightTask>(t => t.HideSeries == value, t => t.HideSeries = value);
    }

    /// <summary>
    /// Gets or sets a value indicating whether 使用周计划。
    /// </summary>
    public bool UseWeeklySchedule
    {
        get => GetTaskConfig<FightTask>().UseWeeklySchedule;
        set {
            if (SetTaskConfig<FightTask>(t => t.UseWeeklySchedule == value, t => t.UseWeeklySchedule = value) && value)
            {
                HideUnavailableStage = false;
            }
        }
    }

    public ObservableCollection<WeeklyScheduleItem> WeeklyScheduleSource { get; set; } = [.. Enum.GetValues<DayOfWeek>().Select(i => new WeeklyScheduleItem(i))];

    private static string ToUpperAndCheckStage(string value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return value;
        }

        string upperValue = value.ToUpper();
        if (_stageDictionary.TryGetValue(upperValue, out var stage))
        {
            return stage;
        }

        if (Instance.StageListSource == null)
        {
            return value;
        }

        foreach (var item in Instance.StageListSource)
        {
            if (upperValue.Equals(item.Value, StringComparison.CurrentCultureIgnoreCase) || upperValue.Equals(item.Display, StringComparison.CurrentCultureIgnoreCase))
            {
                return item.Value;
            }
        }

        return value;
    }

    public static string? GetFightStage(IEnumerable<string> list)
    {
        var stage = list?.FirstOrDefault(s => Instances.StageManager.IsStageOpen(s, Instances.TaskQueueViewModel.CurDayOfWeek));
        _logger.Information("GetFightStage: from {list}, selected {stage}", list, stage);
        return stage;
    }

    /// <summary>
    /// 战斗任务正常结束但未达库存目标时，记录其临期药窗口为已耗尽。
    /// 无次数上限的任务未达标即结束只可能是理智不足，且结束前已尝试用尽窗口内的临期药；
    /// 运行内药剂库存只减不增，故窗口取历史最大值，供后续任务判定是否可跳过。
    /// </summary>
    /// <param name="expireDays">该任务的临期药天数（未启用传 0，无证明力）。</param>
    /// <param name="dropId">指定掉落材料 ID。</param>
    /// <param name="dropCount">目标库存。</param>
    public static void UpdateProvenExhaustedMedicineDays(int expireDays, string dropId, int dropCount)
    {
        if (expireDays <= 0 || string.IsNullOrEmpty(dropId) || dropCount <= 0)
        {
            return;
        }

        if (Instances.ToolboxViewModel?.GetDepotSnapshot() is not { } depotList)
        {
            return; // 库存数据为空时无法判定是否达标，不构成耗尽证明
        }

        var currentCount = depotList.TryGetValue(dropId, out var value) ? value : 0;
        if (currentCount >= dropCount)
        {
            return; // 已达库存目标，结束原因与理智无关，不构成耗尽证明
        }

        ProvenExhaustedMedicineDays = Math.Max(ProvenExhaustedMedicineDays, expireDays);
        _logger.Information("Proven exhausted medicine days updated to {Days} ({DropId} {Current}/{Target} on normal completion)",
            ProvenExhaustedMedicineDays, dropId, currentCount, dropCount);
    }

    /// <summary>
    /// 任务开始时用最新库存重算指定掉落材料的缺口：达标则 times=0 跳过整个任务（核心侧不进终端不导航）；
    /// 否则更新 drops，并在理智不足且无药剂/源石预算、临期药窗口已证明耗尽（或未启用）时同样 times=0 跳过。
    /// 库存数据为空（从未成功识别过库存）时同样 times=0 跳过并记录警告，按 0 计缺口会把目标量全额下发。
    /// 供理智作战和库存保持任务统一调用。
    /// </summary>
    /// <param name="taskId">core 任务 id</param>
    /// <param name="dropId">指定掉落材料 ID</param>
    /// <param name="dropCount">目标库存</param>
    /// <param name="logLabel">日志标签（如计划序号）</param>
    /// <param name="task">包含全量字段的作战任务参数；本方法仅按库存缺口或理智判定覆盖 Drops/MaxTimes，其余字段原样下发。</param>
    /// <param name="countDualChipAsChipPack">是否将双芯片按合成配方折算计入当前数量（库存保持任务按其配置传入，理智作战恒为 false）。</param>
    /// <returns>是否成功更新参数。</returns>
    public static bool RefreshFightTaskDrops(int taskId, string dropId, int dropCount, string? logLabel, AsstFightTask task, bool countDualChipAsChipPack = false)
    {
        if (taskId <= 0 || string.IsNullOrEmpty(dropId) || dropCount <= 0)
        {
            return false;
        }

        // 库存数据为空说明从未成功识别过库存，缺口无从谈起，times=0 停刷等待重新识别
        if (Instances.ToolboxViewModel?.GetDepotSnapshot() is not { } depotList)
        {
            task.MaxTimes = 0;
            Instances.TaskQueueViewModel.AddLog(
                LocalizationHelper.GetStringFormat("TaskQueue.DepotMaintain.PlanInventoryDataEmpty", logLabel ?? string.Empty),
                UiLogColor.Warning);
            return Instances.AsstProxy.AsstSetTaskParamsEncoded(taskId, task);
        }

        var currentCount = depotList.TryGetValue(dropId, out var value) ? value : 0;
        if (countDualChipAsChipPack)
        {
            currentCount += DepotMaintainTaskUserControlModel.GetDualChipConversion(dropId, depotList);
        }

        var need = dropCount - currentCount;

        var dropName = ItemListHelper.GetItemName(dropId) ?? dropId;

        if (need <= 0)
        {
            // 库存已充足，times=0 跳过整个任务
            task.MaxTimes = 0;
            Instances.TaskQueueViewModel.AddLog(
                LocalizationHelper.GetStringFormat("TaskQueue.DepotMaintain.PlanInventoryEnough", logLabel ?? string.Empty, dropName, currentCount.ToString("N0"), dropCount.ToString("N0")),
                UiLogColor.Info);
        }
        else
        {
            task.Drops = new() { { dropId, need } };
            Instances.TaskQueueViewModel.AddLog(
                LocalizationHelper.GetStringFormat("TaskQueue.DepotMaintain.PlanInventoryInsufficient", logLabel ?? string.Empty, dropName, currentCount.ToString("N0"), dropCount.ToString("N0"), need.ToString("N0")));
            _logger.Information("FightTask {taskId} ({label}) re-calculated: {dropName} need {need} (current {current} / target {target})",
                taskId, logLabel, dropName, need, currentCount, dropCount);

            // 理智不足且无药剂/源石预算、临期药窗口已证明耗尽（或未启用）时，跳过整个任务，不再导航进图查看
            if (task.Medicine <= 0 && task.Stone <= 0 &&
                (task.MedicineExpireDays <= 0 || task.MedicineExpireDays <= ProvenExhaustedMedicineDays) &&
                SanityReport is { } sanity)
            {
                var apCost = StageApCostHelper.GetApCost(task.Stage);
                if (apCost is null)
                {
                    // 关卡消耗未知（手输关卡、复刻前缀等），无法进行理智判定，记录日志保持可观测
                    _logger.Information("FightTask {taskId} ({label}) stage {Stage} has no apCost data, sanity skip check not performed",
                        taskId, logLabel, task.Stage);
                }
                else
                {
                    // 按上报时间以 6 分钟 1 点估算自然回复（向上取整、封顶上限），估算值不低于真实值，长队列后也不会误跳
                    var regen = sanity.SanityCurrent < sanity.SanityMax
                        ? Math.Max(0, (int)Math.Ceiling((DateTimeOffset.Now - sanity.ReportTime).TotalMinutes / 6))
                        : 0;
                    var estimatedSanity = Math.Min(sanity.SanityCurrent + regen, sanity.SanityMax);
                    if (estimatedSanity < apCost)
                    {
                        task.MaxTimes = 0;
                        Instances.TaskQueueViewModel.AddLog(
                            LocalizationHelper.GetStringFormat("TaskQueue.DepotMaintain.PlanSanityInsufficient", logLabel ?? string.Empty, estimatedSanity, apCost),
                            UiLogColor.Info);
                    }
                }
            }
        }

        return Instances.AsstProxy.AsstSetTaskParamsEncoded(taskId, task);
    }

    /// <summary>
    /// 按理智作战配置构建核心 Fight 任务参数，append 序列化与任务开始时的重算共用，保证两处参数一致。
    /// 含活动临期药窗口扩展（把窗口拉长到本周结束）与剿灭自定义关卡替换；次数上限由调用方决定，掉落目标由调用方追加。
    /// </summary>
    /// <param name="fight">理智作战任务配置。</param>
    /// <param name="stage">已解析的关卡。</param>
    /// <param name="maxTimes">最大战斗次数。</param>
    /// <returns>核心 Fight 任务参数。</returns>
    private static AsstFightTask BuildAsstFightTask(FightTask fight, string stage, int maxTimes)
    {
        var time = DateTimeOffset.Now;
        var activityExpireIn2Days = false;
        var activityList = Instances.StageManager.ActivityList
            .Where(ss => ss.Value.Info.StartTimeUtc <= time && time <= ss.Value.Info.ExpireTimeUtc);
        if (activityList.Any())
        {
            var activity = activityList.First();
            activityExpireIn2Days = (activity.Value.Info.ExpireTimeUtc - time).Days < 2;
        }

        var expireDays = fight.UseExpiringMedicine ? fight.MedicineExpireDays : 0;
        var yjTime = DateTimeOffset.Now.ToYjDateTime().ToLocalTime();
        var daysUntilEndOfWeek = ((7 - (int)yjTime.DayOfWeek + 7) % 7) + 1; // 距离本周结束的天数, 用鹰历计算
        var activityExpireDays = activityExpireIn2Days && fight.UseExpireMedicineForActivity ? daysUntilEndOfWeek : 0;

        var task = new AsstFightTask() {
            Stage = stage,
            Medicine = fight.UseMedicine != false ? fight.MedicineCount : 0,
            Stone = fight.UseStone != false ? fight.StoneCount : 0,
            Series = fight.Series,
            MaxTimes = maxTimes,
            MedicineExpireDays = Math.Max(expireDays, activityExpireDays),
            IsDrGrandet = fight.IsDrGrandet,
            ReportToPenguin = SettingsViewModel.ThirdPartyServiceSettings.EnablePenguin,
            ReportToYituliu = SettingsViewModel.ThirdPartyServiceSettings.EnableYituliu,
            PenguinId = SettingsViewModel.ThirdPartyServiceSettings.PenguinId,
            ServerType = Instances.SettingsViewModel.ServerType,
            ClientType = SettingsViewModel.GameSettings.ClientType,
        };

        if (task.Stage == AnnihilationName && fight.UseCustomAnnihilation)
        {
            task.Stage = fight.AnnihilationStage;
        }

        return task;
    }

    /// <summary>
    /// 判断指定关卡是否为常驻关卡（无周期限制且非限时活动，每天都开放）。
    /// 资源关（如 LS-6）虽有关联活动但 IsResourceCollection 为 true 且无周期限制，同样视为常驻。
    /// </summary>
    /// <param name="stage">关卡代码。</param>
    /// <returns>若该关卡为常驻关卡则返回 <c>true</c>。</returns>
    private static bool IsPermanentStage(string stage)
    {
        var stageInfo = Instances.StageManager.GetStageInfo(stage);
        bool noPeriodicLimit = stageInfo.OpenDaysOfWeek == null || !stageInfo.OpenDaysOfWeek.Any();
        bool notLimitedActivity = stageInfo.Activity == null || stageInfo.Activity.IsResourceCollection;
        return noPeriodicLimit && notLimitedActivity;
    }

    public override void RefreshUI(BaseTask baseTask)
    {
        if (baseTask is not FightTask fight)
        {
            return;
        }
        using var refresh = new UiRefreshingScope();
        if (!UseAlternateStage && fight.StagePlan.Count == 0)
        {
            fight.StagePlan.Add(string.Empty);
        }
        RefreshStageList();
        RefreshCurrentStagePlan();
        RefreshWeeklySchedule();
        RefreshDropName();
        NotifySpecifiedDropsStateChanged();
        Refresh();
    }

    private bool? SetFightParams()
    {
        if (IsRefreshingUI || TaskSettingVisibilityInfo.CurrentTask is not FightTask fight)
        {
            return null;
        }

        if (ConfigFactory.CurrentConfig.TaskQueue.IndexOf(fight) is int index && index > -1 && Instances.TaskQueueViewModel.TaskItemViewModels[index].TaskIds.Count > 0)
        {
            return SerializeTask(fight, Instances.TaskQueueViewModel.TaskItemViewModels[index].TaskIds[0]).IsSuccess;
        }
        return null;
    }

    public override (bool? IsSuccess, IEnumerable<int> TaskId) SerializeTask(BaseTask? baseTask, int? taskId = null) => (this as ISerialize).Serialize(baseTask, taskId);

    #region 关卡列表更新

    /// <summary>
    /// 更新关卡列表。
    /// 使用手动输入时，只更新关卡列表，不更新关卡选择
    /// 使用隐藏当日不开放时，更新关卡列表，关卡选择为未开放的关卡时清空
    /// 使用备选关卡时，更新关卡列表，关卡选择为未开放的关卡时在关卡列表中添加对应未开放关卡，避免清空导致进入上次关卡
    /// 啥都不选时，更新关卡列表，关卡选择为未开放的关卡时在关卡列表中添加对应未开放关卡，避免清空导致进入上次关卡
    /// 除手动输入外所有情况下，如果剩余理智为未开放的关卡，会被清空
    /// </summary>
    /// <returns>更新任务列表的Task</returns>
    // FIXME：被注入对象只能在 private 函数内使用，只有 Model 显示之后才会被注入。如果 Model 还没有触发 OnInitialActivate 时调用此函数，会导致空引用异常。
    // 这个函数被声明为 public，意味着它可能会在注入对象前被调用。
    public Task UpdateStageList()
    {
        return Execute.OnUIThreadAsync(async () => {
            using var log = new LogScope(_logger);
            var stageList = Instances.StageManager.GetStageList();
            await TaskQueueViewModel.TaskQueueSerializingLock.WaitAsync();
            var time = DateTimeOffset.Now;
            var activityList = Instances.StageManager.ActivityList.Where(ss => ss.Value.Info.StartTimeUtc <= time && time <= ss.Value.Info.ExpireTimeUtc);
            if (activityList.Any())
            {
                var activity = activityList.First();
                var timeLeft = activity.Value.Info.ExpireTimeUtc - time;
                var day = timeLeft.Days > 0 ? $"{timeLeft.Days}+" : LocalizationHelper.GetString("TaskQueue.Stage.Label.LessThanOneDay");
                ActivityExpireIn2Days = timeLeft.Days < 2;
                ActivityInfo = $"｢{activity.Value.Info.StageName}｣ {LocalizationHelper.GetString("TaskQueue.Stage.Label.DaysLeftOpen")}{day}";
            }
            else
            {
                ActivityInfo = LocalizationHelper.GetString("TaskQueue.Fight.NoActivity");
                ActivityExpireIn2Days = false;
            }
            using (var refresh = new UiRefreshingScope())
            {
                RefreshStageList();
                foreach (var task in ConfigFactory.CurrentConfig.TaskQueue.OfType<FightTask>().Where(i => !i.IsStageManually))
                {
                    var originalPlan = task.StagePlan.ToList();
                    bool reset = false;
                    for (int i = 0; i < task.StagePlan.Count; i++)
                    {
                        var stage = task.StagePlan[i];
                        if (!stageList.Any(p => p.Value == stage))
                        {
                            reset = true;
                            if (task.StageResetMode == FightStageResetMode.Current)
                            {
                                task.StagePlan[i] = string.Empty;
                            }
                        }
                    }
                    if (reset)
                    {
                        _logger.Information("Reset non-existing stage: {} to {}", string.Join(", ", originalPlan), string.Join(", ", task.StagePlan));
                    }
                }
                RefreshCurrentStagePlan();
            }
            TaskQueueViewModel.TaskQueueSerializingLock.Release();

            foreach (var (item, index) in Instances.TaskQueueViewModel.TaskItemViewModels.Select((i, index) => (i, index)))
            {
                if (ConfigFactory.Root.CurrentConfig.TaskQueue[index] is FightTask fight && item.TaskIds.Count == 1 && Instances.AsstProxy.TasksStatus.ContainsKey(item.TaskIds[0]))
                {
                    if (SerializeTask(fight, Instances.TaskQueueViewModel.TaskItemViewModels[index].TaskIds[0]).IsSuccess is not true)
                    {
                        _logger.Warning("Failed to serialize task {taskId} when updating stage list", item.TaskIds[0]);
                    }
                }
            }
        });
    }

    private void RefreshStageList()
    {
        if (TaskSettingVisibilityInfo.CurrentTask is not FightTask current)
        {
            return;
        }
        var stageList = Instances.StageManager.GetStageList().ToList();
        var listCurrent = current.StagePlan.ToList();

        var listSource = stageList
            .Select(i => new StageSourceItem() {
                Display = i.Display,
                Value = i.Value,
                IsVisible = !HideUnavailableStage || i.IsStageOpen(Instances.TaskQueueViewModel.CurDayOfWeek),
                IsOpen = Instances.StageManager.GetStageList()
                    .FirstOrDefault(p => p.Value == i.Value)
                    ?.IsStageOpen(Instances.TaskQueueViewModel.CurDayOfWeek) ?? true,
            }).ToList();

        // 补过期关卡进来
        foreach (var item in listCurrent.Where(i => !listSource.Any(p => p.Value == i)))
        {
            listSource.Add(new StageSourceItem() { Display = item, Value = item, IsOpen = false, IsVisible = false, IsOutdated = true });
        }
        listSource.FirstOrDefault(i => i.Value == AnnihilationName)?.Display = current.UseCustomAnnihilation
            ? (AnnihilationModeList.FirstOrDefault(i => i.Value == current.AnnihilationStage)?.Display
                ?? LocalizationHelper.GetString("TaskQueue.Annihilation.Current"))
            : LocalizationHelper.GetString("TaskQueue.Annihilation.Current");
        StageListSource = [.. listSource];
        current.StagePlan = listCurrent; // StageListSource更新后, 恢复StagePlan
    }

    private void RefreshCurrentStagePlan()
    {
        if (TaskSettingVisibilityInfo.CurrentTask is not FightTask current)
        {
            return;
        }
        var plan = current.StagePlan.ToList();
        var list = plan.Select((i, index) => new StagePlanItem(i)).ToList();
        foreach (var item in list)
        {
            item.PropertyChanged += (_, __) => SaveStagePlan();
        }
        StagePlan = [.. list];
        StagePlan.CollectionChanged += (_, __) => SaveStagePlan();
        SetFightParams(); // 恢复StagePlan后, 修复AsstFightTask的Stage
    }

    private void SaveStagePlan()
    {
        var list = StagePlan.Select(i => i.Stage).ToList();
        SetTaskConfig<FightTask>(t => t.StagePlan.SequenceEqual(list), t => t.StagePlan = list);
    }

    private void RefreshWeeklySchedule()
    {
        var plan = GetTaskConfig<FightTask>().WeeklySchedule;
        foreach (var item in WeeklyScheduleSource)
        {
            item.Value = !plan.TryGetValue(item.DayOfWeek, out var value) || value;
        }
    }

    private void SaveWeeklySchedule()
    {
        if (IsRefreshingUI)
        {
            return;
        }

        var dict = WeeklyScheduleSource.ToDictionary(i => i.DayOfWeek, i => i.Value);
        SetTaskConfig<FightTask>(t => t.WeeklySchedule.SequenceEqual(dict), t => t.WeeklySchedule = dict);
    }

    private void RefreshDropName()
    {
        var id = GetTaskConfig<FightTask>().DropId;
        if (AllDrops.FirstOrDefault(i => i.Value == id) is { } item)
        {
            DropsItemName = item.Display;
        }
        else
        {
            SetTaskConfig<FightTask>(t => t.DropId == string.Empty, t => t.DropId = string.Empty);
            DropsItemName = AllDrops.FirstOrDefault(i => i.Value == string.Empty)?.Display ?? string.Empty;
        }
    }

    #endregion 关卡列表更新

    #region Data Class

    public class SanityInfo
    {
        [JsonProperty("current_sanity")]
        public int SanityCurrent { get; set; }

        [JsonProperty("max_sanity")]
        public int SanityMax { get; set; }

        [JsonProperty("report_time")]
        public DateTimeOffset ReportTime { get; set; }
    }

    public class FightTimes
    {
        [JsonProperty("sanity_cost")]
        public int SanityCost { get; set; }

        [JsonProperty("series")]
        public int Series { get; set; }

        [JsonProperty("times_finished")]
        public int TimesFinished { get; set; }

        [JsonProperty("finished")]
        public bool IsFinished { get; set; }
    }

    #endregion Data Class

    #region UI Item

    public class StageSourceItem : PropertyChangedBase
    {
        public string Display { get => field; set => SetAndNotify(ref field, value); } = string.Empty;

        public string Value { get; set; } = string.Empty;

        public bool IsOpen { get => field; set => SetAndNotify(ref field, value); } = true;

        public bool IsVisible { get => field; set => SetAndNotify(ref field, value); } = true;

        /// <summary>
        /// Gets or sets a value indicating whether 关卡已过期并显示删除线。
        /// </summary>
        public bool IsOutdated { get; set; } = false;
    }

    public class StagePlanItem(string stage = "") : PropertyChangedBase
    {
        public string Stage
        {
            get => field;
            set {
                value ??= string.Empty;
                if (TaskSettingVisibilityInfo.CurrentTask is FightTask task && task.UseOptionalStage)
                {
                    // 从后往前删
                    if (value.Length != 3)
                    {
                        value = ToUpperAndCheckStage(value);
                    }
                }

                if (!SetAndNotify(ref field, value))
                {
                    return;
                }

                IsOpen = Instances.StageManager.GetStageList().FirstOrDefault(p => p.Value == value)?.IsStageOpen(Instances.TaskQueueViewModel.CurDayOfWeek) ?? true;
                Instance.SetFightParams();
            }
        } = stage;

        // 仅供 ComboBox本身 和 手写Stage的TextBlock 绑定使用
        public bool IsOpen { get => field; set => SetAndNotify(ref field, value); } = Instances.TaskQueueViewModel.IsStageOpen(stage);
    }

    #endregion UI Item

    private interface ISerialize : ITaskQueueModelSerialize
    {
        (bool? IsSuccess, IEnumerable<int> TaskId) ITaskQueueModelSerialize.Serialize(BaseTask? baseTask, int? taskId)
        {
            if (baseTask is not FightTask fight || taskId is int and <= 0)
            {
                return (null, []);
            }

            if (fight.UseWeeklySchedule && fight.WeeklySchedule.TryGetValue(Instances.TaskQueueViewModel.CurDayOfWeek, out var isEnabled) && !isEnabled)
            {
                Instances.TaskQueueViewModel.AddLog(LocalizationHelper.GetString("TaskQueue.Fight.SkippedWeeklySchedule"), UiLogColor.Info);
                return (null, []);
            }

            string? stage = GetFightStage(fight.StagePlan);
            if (stage is null)
            {
                if (fight.StagePlan.Count == 0)
                {
                    Instances.TaskQueueViewModel.AddLog(LocalizationHelper.GetString("TaskQueue.Fight.SkippedEmptyStagePlan"), UiLogColor.Error);
                }
                else
                {
                    Instances.TaskQueueViewModel.AddLog(LocalizationHelper.GetString("TaskQueue.Fight.SkippedNoOpenStage"), UiLogColor.Info);
                }

                return (null, []);
            }

            // 选关逻辑为从上至下找第一个开放关卡，
            // 常驻关卡（如剿灭、1-7）或"当前/上次"（空字符串）一旦被选中便不会继续往下查找，
            // 因此其后配置的关卡不会被选中执行
            if (taskId is null && (stage == string.Empty || IsPermanentStage(stage)))
            {
                int stageIndex = fight.StagePlan.IndexOf(stage);
                if (stageIndex >= 0 && stageIndex < fight.StagePlan.Count - 1)
                {
                    var stageName = stage == string.Empty
                        ? LocalizationHelper.GetString("TaskQueue.Stage.Label.Default")
                        : Instances.StageManager.GetStageInfo(stage).Display;
                    Instances.TaskQueueViewModel.AddLog(
                        LocalizationHelper.GetStringFormat("TaskQueue.Fight.PermanentStageBlocksStages", stageName),
                        UiLogColor.Warning);
                }
            }

            InventoryTargetRuntimeState? inventoryTargetRuntimeState = null;
            bool shouldRememberInventoryTargetRuntimeState = false;
            int specifiedDropsQuantity = fight.DropCount;

            if (IsInventoryTargetDropEnabled(fight))
            {
                if (taskId is int existingTaskId and > 0 && Instance.GetInventoryTargetRuntimeState(existingTaskId) is { } existingRuntimeState)
                {
                    inventoryTargetRuntimeState = existingRuntimeState;
                }
                else
                {
                    inventoryTargetRuntimeState = CreateInventoryTargetRuntimeState(fight);
                    if (taskId is int startedTaskId and > 0 && inventoryTargetRuntimeState != null && IsTaskInProgress(startedTaskId))
                    {
                        shouldRememberInventoryTargetRuntimeState = true;
                    }
                }

                if (inventoryTargetRuntimeState == null)
                {
                    Instances.TaskQueueViewModel.AddLog(LocalizationHelper.GetStringFormat("TaskQueue.Fight.SpecifiedDropsInventoryUnavailable", fight.NameOrTaskType), UiLogColor.Warning);
                    return (null, []);
                }

                specifiedDropsQuantity = inventoryTargetRuntimeState.EffectiveQuantity;
                if (specifiedDropsQuantity <= 0 && taskId is null)
                {
                    var dropName = ItemListHelper.GetItemName(fight.DropId) ?? fight.DropId;
                    Instances.TaskQueueViewModel.AddLog(
                        LocalizationHelper.GetStringFormat("TaskQueue.Fight.SpecifiedDropsInventoryEnough", dropName, inventoryTargetRuntimeState.StartInventory.ToString("N0"), fight.DropCount.ToString("N0")),
                        UiLogColor.Info);
                    return (null, []);
                }
            }

            var effectiveMaxTimes = fight.EnableTimesLimit != false ? fight.TimesLimit : int.MaxValue;

            // 任务运行时如果启用了目标掉落且指定的掉落数量小于等于 0，则将最大挑战次数设为 0，防止任务继续运行但无法获得目标掉落
            if (taskId is int and > 0 && IsInventoryTargetDropEnabled(fight) && specifiedDropsQuantity <= 0)
            {
                effectiveMaxTimes = 0;
            }

            var task = BuildAsstFightTask(fight, stage, effectiveMaxTimes);

            if (fight.EnableTargetDrop != false && !string.IsNullOrEmpty(fight.DropId) && specifiedDropsQuantity > 0)
            {
                task.Drops.Add(fight.DropId, specifiedDropsQuantity);
            }

            if (effectiveMaxTimes > 0 && effectiveMaxTimes < int.MaxValue && fight.Series > 0 && effectiveMaxTimes % fight.Series != 0)
            {
                Instances.TaskQueueViewModel.AddLog(LocalizationHelper.GetStringFormat("TaskQueue.FightTimesMayNotExhausted", effectiveMaxTimes, fight.Series), UiLogColor.Warning);
            }

            if (taskId is int id and > 0)
            {
                bool updated = Instances.AsstProxy.AsstSetTaskParamsEncoded(id, task);
                if (updated && shouldRememberInventoryTargetRuntimeState && inventoryTargetRuntimeState != null)
                {
                    Instance.RememberInventoryTargetRuntimeState(id, inventoryTargetRuntimeState);
                }

                return (updated, [id]);
            }

            if (taskId is null)
            {
                var appendResult = Instances.AsstProxy.AsstAppendTaskWithEncoding(TaskType.Fight, task);
                return (appendResult.IsSuccess, appendResult.TaskId > 0 ? [appendResult.TaskId] : []);
            }

            return (null, []);
        }
    }

    private struct UiRefreshingScope : IDisposable
    {
        private static int _depth = 0;

        public UiRefreshingScope()
        {
            ++_depth;
            Instance.IsRefreshingUI = true;
        }

        readonly void IDisposable.Dispose()
        {
            --_depth;
            if (_depth == 0)
            {
                Instance.IsRefreshingUI = false;
            }
        }
    }

    #region Model

    private record MedicineUsingInfo([property: JsonProperty("is_expiring")] bool IsExpiring, [property: JsonProperty("count")] int Count, [property: JsonProperty("medicines")] List<MedicineInfo>? Medicines);

    private record MedicineInfo([property: JsonProperty("use")] int Use, [property: JsonProperty("inventory")] int Inventory, [property: JsonProperty("expire_days")] int ExpireDays);

    private sealed record InventoryTargetRuntimeState(string DropId, int StartInventory, int EffectiveQuantity);

    #endregion Model
}
