// <copyright file="RootViewModel.cs" company="MaaAssistantArknights">
// Part of the MaaWpfGui project, maintained by the MaaAssistantArknights team (Maa Team)
// Copyright (C) 2021-2026 MaaAssistantArknights Contributors
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License v3.0 only as published by
// the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY
// </copyright>

#nullable enable

using System;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using HandyControl.Controls;
using HandyControl.Data;
using HandyControl.Tools;
using JetBrains.Annotations;
using MaaWpfGui.Configuration.Factory;
using MaaWpfGui.Extensions;
using MaaWpfGui.Helper;
using MaaWpfGui.Main;
using MaaWpfGui.Models;
using MaaWpfGui.Services;
using MaaWpfGui.ViewModels.UserControl.Settings;
using Microsoft.WindowsAPICodePack.Taskbar;
using Serilog;
using Stylet;
using Point = System.Windows.Point;

namespace MaaWpfGui.ViewModels.UI;

/// <summary>
/// The root view model.
/// </summary>
public class RootViewModel : Conductor<Screen>.Collection.OneActive
{
    private static readonly ILogger _logger = Log.ForContext<RootViewModel>();

    /// <inheritdoc/>
    protected override void OnViewLoaded()
    {
        InitViewModels();
        _ = InitProxy();

        // 宿醉彩蛋弹窗依赖 RootView 已渲染完毕的 Dialog 容器，
        // 必须在主窗口显示之后再弹出，否则弹不出
        // 必须在其他内容初始化之前执行，否则其他内容语言可能已经被初始化为非宿醉语言
        Instances.SettingsViewModel.HangoverEnd();

        if (Bootstrapper.IsDemoMode)
        {
            // README 截图演示模式：跳过版本不匹配提示、Nightly 提示、公告下载、
            // 完整性/更新检查与配置损坏等弹窗，避免联网与弹窗干扰自动截图
            return;
        }

        if (Bootstrapper.IsCoreInitSkipped)
        {
            // UI 预览模式：Core 未加载时版本号比对必然触发版本不匹配错误弹窗，
            // 更新/公告/完整性检查等联网弹窗同样干扰界面预览，一并跳过
            return;
        }

        ShowVersionMismatchWarningOnStartup();
        if (SettingsViewModel.VersionUpdateSettings.VersionType == VersionUpdateSettingsUserControlModel.UpdateVersionType.Nightly &&
            !SettingsViewModel.VersionUpdateSettings.HasAcknowledgedNightlyWarning)
        {
            MessageBoxHelper.Show(LocalizationHelper.GetString("VersionUpdate.NightlyWarning"));
        }

        Task.Run(async () => {
            await Instances.AnnouncementDialogViewModel.CheckAndDownloadAnnouncement();
            if (Instances.AnnouncementDialogViewModel.DoNotRemindThisAnnouncementAgain)
            {
                return;
            }

            if (Instances.AnnouncementDialogViewModel.DoNotShowAnnouncement)
            {
                return;
            }

            if (Instances.AnnouncementDialogViewModel.AnnouncementInfo != string.Empty)
            {
                _ = Execute.OnUIThreadAsync(() => Instances.WindowManager.ShowWindow(Instances.AnnouncementDialogViewModel));
            }
        });

        _ = StartupIntegrityCheckAndUpdateAsync();

        // 主窗口已显示，此时弹窗不会导致 WPF 因无窗口而退出
        Task.Run(ConfigBrokenCheck);
        Task.Run(ToastNotificationCheck);
    }

    /// <summary>
    /// 启动时的完整性检查与更新检查。
    /// 对照 filelist.txt 检查安装文件是否缺失，缺失时弹窗询问是否修复（重新下载完整包）；
    /// 未缺失、用户选择忽略、或修复未完成（失败/用户取消）时回退常规更新检查。
    /// 资源已标记损坏时本检查整体跳过（扫描前后各检测一次标志），修复入口由资源损坏弹窗统一提供，
    /// 不再叠加缺失弹窗或常规更新弹窗。前检测拦 OnStart 已置位的更新失败标志（时序有同步保证），
    /// 后检测拦扫描期间 Init 才置位的资源损坏（两者并发赛跑）。
    /// 必须在主窗口显示之后执行，否则弹窗会成为唯一窗口，关闭时触发 WPF 退出。
    /// </summary>
    private static async Task StartupIntegrityCheckAndUpdateAsync()
    {
        if (Bootstrapper.IsResourceBroken)
        {
            _logger.Information("Skip startup integrity check, resource-broken dialog takes over");
            return;
        }

        var missingFiles = await Task.Run(ResourceIntegrityChecker.GetMissingFiles);

        // 后检测：资源在扫描期间才标记损坏（与 Init 并发）时也不再叠任何弹窗，缺失数与是否缺失无关
        if (Bootstrapper.IsResourceBroken)
        {
            _logger.Information("Skip integrity and update check, resource-broken dialog takes over, {Count} file(s) missing", missingFiles.Count);
            return;
        }

        if (missingFiles.Count > 0)
        {
            var shownFiles = string.Join(", ", missingFiles.Take(5));
            if (missingFiles.Count > 5)
            {
                shownFiles += ", …";
            }

            var repairChoice = MessageBoxHelper.Show(
                LocalizationHelper.GetStringFormat("VersionUpdate.IntegrityCheck.Description", missingFiles.Count, shownFiles),
                LocalizationHelper.GetString("VersionUpdate.IntegrityCheck.Title"),
                MessageBoxButton.YesNo,
                MessageBoxImage.Error,
                yes: LocalizationHelper.GetString("VersionUpdate.IntegrityRepair.Yes"),
                no: LocalizationHelper.GetString("VersionUpdate.IntegrityRepair.No"));
            if (repairChoice == MessageBoxResult.Yes)
            {
                // 修复优先于常规更新检查，注册完成后会提示重启
                _logger.Information("Integrity repair accepted by user, {Count} file(s) missing", missingFiles.Count);
                var repairResult = await Instances.VersionUpdateDialogViewModel.RunIntegrityRepairAsync();
                if (repairResult is Dialogs.VersionUpdateDialogViewModel.IntegrityRepairResult.Succeeded
                    or Dialogs.VersionUpdateDialogViewModel.IntegrityRepairResult.AlreadyRunning)
                {
                    // AlreadyRunning 表示另一弹窗路径的修复仍在进行，由那条链路收尾，此处不叠加常规更新检查
                    return;
                }

                if (repairResult == Dialogs.VersionUpdateDialogViewModel.IntegrityRepairResult.Canceled)
                {
                    // 用户主动取消修复：仍执行常规更新检查，持续取消时才不会一直收不到更新提示
                    _logger.Information("Integrity repair canceled by user, falling back to regular update check");
                }
                else
                {
                    // 修复失败时回退常规更新检查：完整包升级可补齐缺失文件，
                    // 但 OTA 增量只含版本间变化的文件，未变化的缺失文件不会被补上
                    _logger.Warning("Integrity repair failed, falling back to regular update check");
                }
            }
            else
            {
                _logger.Warning("Integrity repair declined by user, {Count} file(s) missing", missingFiles.Count);
            }
        }

        // 修复仍在进行中（另一弹窗路径已接受修复）时不叠加常规更新检查，避免下载与弹窗互相干扰；
        // 修复已结束（失败/取消）时标志已复位，回退常规更新检查的行为不变
        if (Instances.VersionUpdateDialogViewModel.IsIntegrityRepairRunning)
        {
            _logger.Information("Skip regular update check, integrity repair in progress");
            return;
        }

        await Instances.VersionUpdateDialogViewModel.ShowUpdateOrDownload();
    }

    private static void ConfigBrokenCheck()
    {
        var recoveryMessage = ConfigFactory.ConsumePendingRecoveryMessage();
        if (recoveryMessage is not null)
        {
            MessageBoxHelper.Show(recoveryMessage, LocalizationHelper.GetString("Error.ConfigurationBrokenCaption"), MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private static void ToastNotificationCheck()
    {
        if (!SettingsViewModel.NotificationSettings.UseNotify)
        {
            return;
        }

        var (isAvailable, detail) = ToastNotification.ToastNotificationCheck();
        if (!isAvailable)
        {
            GrowlHelper.Error(LocalizationHelper.GetStringFormat("Toast.Unavailable", detail));
            _logger.Error(LocalizationHelper.GetStringFormat("Toast.Unavailable", detail));
        }
    }

    private static void ShowVersionMismatchWarningOnStartup()
    {
        var uiVersion = VersionUpdateSettingsUserControlModel.UiVersion;
        var coreVersion = VersionUpdateSettingsUserControlModel.CoreVersion;
        if (!Instances.VersionUpdateDialogViewModel.IsDebugVersion() && uiVersion != coreVersion)
        {
            MessageBoxHelper.Show(
                LocalizationHelper.GetStringFormat("VersionUpdate.VersionMismatch", uiVersion, coreVersion),
                LocalizationHelper.GetString("Common.Error"),
                iconKey: ResourceToken.FatalGeometry,
                iconBrushKey: ResourceToken.DangerBrush);
        }
    }

    private static async Task InitProxy()
    {
        try
        {
            await Task.Run(Instances.AsstProxy.Init);
        }
        catch (Exception e)
        {
            // 初始化失败除 Link Start 保持置灰外无任何表现，不落日志则无从定位（如 Core 与资源版本不匹配）
            _logger.Error(e, "Failed to init AsstProxy");
        }
    }

    private void InitViewModels()
    {
        Items.Add(Instances.TaskQueueViewModel);
        Items.Add(Instances.CopilotViewModel);
        Items.Add(Instances.LocalAiViewModel);
        Items.Add(Instances.ToolboxViewModel);
        Items.Add(Instances.SettingsViewModel);

        Instances.SettingsViewModel.UpdateWindowTitle(); // 在标题栏上显示模拟器和IP端口 必须在 Items.Add(settings)之后执行。
        ActiveItem = Instances.TaskQueueViewModel;
    }

    private string _windowTitle = "MAA";

    /// <summary>
    /// Gets or sets the window title.
    /// </summary>
    public string WindowTitle
    {
        get => _windowTitle;
        set => SetAndNotify(ref _windowTitle, value);
    }

    private string _windowVersionUpdateInfo = FakeUpdateHelper.HasPendingFakeUpdate
        ? $"{LocalizationHelper.GetString("VersionUpdate.NewVersionFound.Title")}: {FakeUpdateHelper.TargetVersion}"
        : string.Empty;

    /// <summary>
    /// Gets or sets the version update info.
    /// </summary>
    public string WindowVersionUpdateInfo
    {
        get => _windowVersionUpdateInfo;
        set => SetAndNotify(ref _windowVersionUpdateInfo, value);
    }

    private string _windowResourceUpdateInfo = string.Empty;

    /// <summary>
    /// Gets or sets the resource update info.
    /// </summary>
    public string WindowResourceUpdateInfo
    {
        get => _windowResourceUpdateInfo;
        set => SetAndNotify(ref _windowResourceUpdateInfo, value);
    }

    private (int Current, int Max)? _taskProgress;

    /// <summary>
    /// Gets or sets the TaskProgress.
    /// 0.0 to 1.0.
    /// 置 0 以隐藏进度条.
    /// </summary>
    public (int Current, int Max)? TaskProgress
    {
        get => _taskProgress;
        set {
            SetAndNotify(ref _taskProgress, value);

            Execute.OnUIThreadAsync(() => {
                if (Application.Current.MainWindow == null || !Application.Current.MainWindow.IsVisible)
                {
                    return;
                }

                try
                {
                    if (value is null)
                    {
                        TaskbarManager.Instance.SetProgressValue(0, 0, Application.Current.MainWindow);
                    }
                    else
                    {
                        TaskbarManager.Instance.SetProgressValue(value.Value.Current, value.Value.Max, Application.Current.MainWindow);
                    }
                }
                catch (Exception e)
                {
                    // 不知道会不会有异常，先捕获一下
                    Logger.Warning("TaskbarManager Exception: " + e.Message);
                }
            });
        }
    }

    /// <summary>
    /// Gets or sets a value indicating whether to scroll the window title.
    /// </summary>
    public bool WindowTitleScrollable { get; set => SetAndNotify(ref field, value); } = ConfigFactory.Root.Gui.WindowTitleScrollable;

    /// <summary>
    /// Gets or sets a value indicating whether to show close button.
    /// </summary>
    public bool ShowCloseButton { get; set => SetAndNotify(ref field, value); } = !ConfigFactory.Root.Gui.HideCloseButton;

    private bool _isWindowTopMost;

    public bool IsWindowTopMost
    {
        get => _isWindowTopMost;
        set {
            if (_isWindowTopMost == value)
            {
                return;
            }

            SetAndNotify(ref _isWindowTopMost, value);
        }
    }

    // UI 绑定的方法
    [UsedImplicitly]
    public void ToggleTopMostCommand()
    {
        IsWindowTopMost = !IsWindowTopMost;
    }

    [UsedImplicitly]
    public void ManualPackagePreviewDragOver(object sender, DragEventArgs e)
    {
        if (!TryGetDroppedZipFile(e, out _))
        {
            return;
        }

        e.Effects = DragDropEffects.Copy;
        e.Handled = true;
    }

    [UsedImplicitly]
    public async void ManualPackageDrop(object sender, DragEventArgs e)
    {
        if (!TryGetDroppedZipFile(e, out string packagePath))
        {
            return;
        }

        _logger.Information("Dropped zip file detected in main window: {PackagePath}", packagePath);
        e.Handled = true;
        await HandleImportedPackageAsync(packagePath);
    }

    /// <inheritdoc/>
    protected override void OnClose()
    {
        Bootstrapper.Shutdown();
    }

    private static readonly string[] _gitList =
    [
        "/Res/Img/EasterEgg/1.gif",
        "/Res/Img/EasterEgg/2.gif",
        "/Res/Img/EasterEgg/3.gif",
    ];

    private static int _gifIndex = -1;

    private static string _gifPath = string.Empty;

    private static bool TryGetDroppedZipFile(DragEventArgs e, out string packagePath)
    {
        packagePath = string.Empty;
        if (!e.Data.GetDataPresent(DataFormats.FileDrop))
        {
            return false;
        }

        if (e.Data.GetData(DataFormats.FileDrop) is not string[] files || files.Length == 0)
        {
            return false;
        }

        string candidatePath = files[0];
        if (!File.Exists(candidatePath) || !candidatePath.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        packagePath = candidatePath;
        return true;
    }

    private static async Task HandleImportedPackageAsync(string packagePath)
    {
        string currentVersion = VersionUpdateSettingsUserControlModel.CoreVersion;
        string architecture = RuntimeInformation.OSArchitecture.ToString().ToLowerInvariant();
        string normalizedArchitecture = architecture.StartsWith("arm", StringComparison.OrdinalIgnoreCase)
            ? "arm64"
            : "x64";

        try
        {
            // 强制完整包更新期间最常见的版本状态是当前版本即最新，用户从官网重下的同版本完整包是此期间的官方自救途径
            bool forceFullPackageUpdate = Dialogs.VersionUpdateDialogViewModel.ShouldForceFullPackageUpdate;
            PendingUpdateApplier.PackageInspectionResult packageInspection =
                PendingUpdateApplier.InspectLocalUpdatePackage(packagePath, currentVersion, architecture, allowSameVersion: forceFullPackageUpdate);

#if DEBUG
            // Debug 专用：Ctrl+Shift 拖入时只做检测判断，不实际注册，用于快速验证正则匹配
            if (Keyboard.Modifiers == (ModifierKeys.Control | ModifierKeys.Shift))
            {
                await DebugInspectDroppedPackageAsync(packagePath, packageInspection, currentVersion, normalizedArchitecture);
                return;
            }
#endif

            // 不是版本更新包文件名模式时，尝试作为资源更新包导入（需读取 zip entry，开销较高）
            if (!packageInspection.MatchedPattern)
            {
                // zip 扫描开销较高（万级 entry），放到后台线程避免卡 UI
                var (isResourcePackage, resourceDateTime) = await Task.Run(() => {
                    bool result = ResourceUpdater.IsResourcePackage(packagePath, out DateTimeOffset dt);
                    return (result, dt);
                });

                if (isResourcePackage)
                {
                    _logger.Information("Dropped package detected as resource package: {PackagePath}", packagePath);
                    _ = ResourceUpdater.ImportLocalResourcePackageAndReloadAsync(packagePath, resourceDateTime);
                    return;
                }

                ShowUnsupportedPackageWarning(packagePath, currentVersion, normalizedArchitecture);
                return;
            }

            // 资源损坏/上次更新失败期间 OTA 增量只含差异文件，修不好残留的不一致文件，拖入入口同样只接受完整包
            if (packageInspection.Status == PendingUpdateApplier.PackageInspectionStatus.OtaSupported
                && forceFullPackageUpdate)
            {
                _logger.Information("Dropped OTA package rejected while installation is broken: {PackagePath}", packagePath);
                MessageBoxHelper.Show(
                    LocalizationHelper.GetString("VersionUpdate.OtaRejectedByBrokenInstall"),
                    LocalizationHelper.GetString("Common.Warning"),
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                return;
            }

            // 版本更新包模式匹配，但架构或版本方向被拒
            if (!packageInspection.IsSupported)
            {
                ShowUnsupportedPackageWarning(packagePath, currentVersion, normalizedArchitecture);
                return;
            }

            // 完整包覆盖安装需用户二次确认（OTA 增量包不需要）
            if (packageInspection.Status == PendingUpdateApplier.PackageInspectionStatus.FullSupported
                && !Dialogs.VersionUpdateDialogViewModel.ConfirmFullPackageUpdate(packagePath))
            {
                _logger.Information("Dropped full package import canceled by user before registration: {PackagePath}", packagePath);
                return;
            }

            var importResult = PendingUpdateApplier.TryRegisterLocalPackage(
                packagePath,
                currentVersion,
                architecture,
                packageInspection);
            _logger.Information(
                "Dropped zip import result: status={Status}, sourceVersion={SourceVersion}, targetVersion={TargetVersion}",
                importResult.Status,
                importResult.SourceVersion,
                importResult.TargetVersion);

            if (importResult.Status
                is PendingUpdateApplier.LocalPackageImportStatus.OtaPackageRegistered
                or PendingUpdateApplier.LocalPackageImportStatus.FullPackageRegistered)
            {
                string targetVersion = importResult.TargetVersion ?? string.Empty;
                bool preserveExistingUpdateInfo = PendingUpdateApplier.ShouldPreserveExistingUpdateBody(targetVersion);
                Instances.VersionUpdateDialogViewModel.UpdateTag = targetVersion;
                if (!preserveExistingUpdateInfo)
                {
                    Instances.VersionUpdateDialogViewModel.UpdateInfo = string.Empty;
                }

                Instances.VersionUpdateDialogViewModel.UpdatePackageName = packagePath;
                _logger.Information(
                    "Showing restart prompt for imported update package: {PackagePath}, status={Status}",
                    packagePath,
                    importResult.Status);
                _ = Instances.VersionUpdateDialogViewModel.AskToRestartForImportedPackage();
                return;
            }

            ShowUnsupportedPackageWarning(packagePath, currentVersion, normalizedArchitecture);
        }
        catch (Exception ex)
        {
            _logger.Error(ex, "Failed to handle imported package: {PackagePath}", packagePath);
            ShowUnsupportedPackageWarning(packagePath, currentVersion, normalizedArchitecture);
        }
    }

    private static void ShowUnsupportedPackageWarning(string packagePath, string currentVersion, string normalizedArchitecture)
    {
        _logger.Warning("Showing unsupported package warning for dropped package: {PackagePath}", packagePath);
        MessageBoxHelper.Show(
            LocalizationHelper.GetStringFormat("VersionUpdate.LocalUpdatePackageUnsupported", Path.GetFileName(packagePath), currentVersion, normalizedArchitecture),
            LocalizationHelper.GetString("Common.Warning"),
            MessageBoxButton.OK,
            MessageBoxImage.Warning,
            ok: LocalizationHelper.GetString("Common.Ok"));
    }

#if DEBUG
    /// <summary>
    /// Debug 专用：展示拖入包的检测结果（状态、版本、架构），不执行注册或解压。
    /// 触发方式：按住 Ctrl+Shift 拖入 zip。
    /// </summary>
    private static async Task DebugInspectDroppedPackageAsync(
        string packagePath,
        PendingUpdateApplier.PackageInspectionResult inspection,
        string currentVersion,
        string normalizedArchitecture)
    {
        var (isResource, resourceDateTime) = await Task.Run(() => {
            bool ok = ResourceUpdater.IsResourcePackage(packagePath, out var dt);
            return (ok, dt);
        });

        string detail = string.Format(
            """
            [DebugInspectDroppedPackage] 仅检测，不注册

            文件: {0}
            当前版本: {1}
            当前架构: {2}

            检测状态: {3}
            MatchedPattern: {4}
            IsSupported: {5}
            SourceVersion: {6}
            TargetVersion: {7}

            是资源包: {8}
            资源包版本: {9}
            """,
            Path.GetFileName(packagePath),
            currentVersion,
            normalizedArchitecture,
            inspection.Status,
            inspection.MatchedPattern,
            inspection.IsSupported,
            inspection.SourceVersion ?? "(null)",
            inspection.TargetVersion ?? "(null)",
            isResource,
            isResource ? resourceDateTime.ToLocalTimeString() : "—");

        _logger.Information("DebugInspectDroppedPackage:\n{Detail}", detail);
        MessageBoxHelper.Show(
            detail,
            "DebugInspectDroppedPackage",
            MessageBoxButton.OK,
            MessageBoxImage.Information);
    }
#endif

    public string GifPath
    {
        get => _gifPath;
        set => SetAndNotify(ref _gifPath, value);
    }

    private bool _gifVisibility = true;

    public bool GifVisibility
    {
        get => _gifVisibility;
        set => SetAndNotify(ref _gifVisibility, value);
    }

    public void ChangeGif()
    {
        if (++_gifIndex >= _gitList.Length)
        {
            _gifIndex = 0;
        }

        GifPath = _gitList[_gifIndex];
    }

    private static bool _isDragging = false;
    private static Point _offset;

    // UI 绑定的方法
    [UsedImplicitly]
    public void DraggableElementMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (sender is not HandyControl.Controls.GifImage childElement)
        {
            return;
        }

        _isDragging = true;
        _offset = e.GetPosition(childElement);
        childElement.CaptureMouse();
    }

    // UI 绑定的方法
    [UsedImplicitly]
    public void DraggableElementMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (sender is not HandyControl.Controls.GifImage childElement)
        {
            return;
        }

        _isDragging = false;
        childElement.ReleaseMouseCapture();
    }

    // UI 绑定的方法
    [UsedImplicitly]
    public void DraggableElementMouseMove(object sender, MouseEventArgs e)
    {
        if (!_isDragging || sender is not HandyControl.Controls.GifImage { Parent: Grid parentElement } childElement)
        {
            return;
        }

        Point currentPosition = e.GetPosition(parentElement);

        // 计算偏移量
        double newX = currentPosition.X - _offset.X;
        double newY = currentPosition.Y - _offset.Y;

        // 确保元素在父元素范围内
        newX = Math.Max(10, Math.Min(newX, parentElement.ActualWidth - childElement.ActualWidth - 10));
        newY = Math.Max(10, Math.Min(newY, parentElement.ActualHeight - childElement.ActualHeight - 10));

        childElement.HorizontalAlignment = HorizontalAlignment.Left;
        childElement.VerticalAlignment = VerticalAlignment.Top;
        childElement.Margin = new(newX, newY, 10, 10);
    }
}
