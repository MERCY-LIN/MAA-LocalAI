// <copyright file="LocalAiView.xaml.cs" company="MaaAssistantArknights">
// Part of the MaaWpfGui project, maintained by the MaaAssistantArknights team (Maa Team)
// Copyright (C) 2021-2026 MaaAssistantArknights Contributors
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License v3.0 only as published by
// the Free Software Foundation, either version 3 of the License, or
// any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY
// </copyright>

namespace MaaWpfGui.Views.UI;

/// <summary>
/// The local AI planning view.
/// </summary>
public partial class LocalAiView : System.Windows.Controls.UserControl
{
    /// <summary>
    /// Initializes a new instance of the <see cref="LocalAiView"/> class.
    /// </summary>
    public LocalAiView()
    {
        InitializeComponent();
    }
}
